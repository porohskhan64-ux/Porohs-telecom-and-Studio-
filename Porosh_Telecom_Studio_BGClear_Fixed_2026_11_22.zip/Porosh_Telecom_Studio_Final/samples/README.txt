Sample previews for mobile and Windows PC. These are illustrative layouts rendered from the current UI design; precise browser font, printer names, and viewport layout may differ.
