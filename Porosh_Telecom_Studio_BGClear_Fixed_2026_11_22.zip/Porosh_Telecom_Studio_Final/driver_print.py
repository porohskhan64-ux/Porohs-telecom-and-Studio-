"""Per-job Windows GDI printing, using DEVMODE without changing printer defaults.

The installed driver can ignore some generic DEVMODE fields; physical verification
of Epson/Canon quality and paper media remains necessary.
"""
import os


def print_pdf_driver(pdf,printer,copies,color,paper,quality):
    if os.name!='nt':raise RuntimeError('Windows 10/11-এ প্রিন্ট করুন')
    import fitz
    import win32print, win32gui, win32con, pywintypes
    from PIL import Image, ImageWin
    names={p[2] for p in win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL|win32print.PRINTER_ENUM_CONNECTIONS)}
    if printer not in names:raise RuntimeError('Windows-এ প্রিন্টারটি পাওয়া যায়নি')
    if quality not in {'draft','normal','high','super'}:raise ValueError('প্রিন্ট কোয়ালিটি সঠিক নয়')
    paper_const={'A4':win32con.DMPAPER_A4,'A5':win32con.DMPAPER_A5,
        'Letter':win32con.DMPAPER_LETTER,'Legal':win32con.DMPAPER_LEGAL}
    # A6 is not universally supported. Require a correct Windows media preset.
    if paper in ('custom','A6'):raise RuntimeError('Custom/A6 কাগজের জন্য Windows ড্রাইভারের Paper Size প্রিসেট ব্যবহার করুন')
    req={'draft':-1,'normal':-3,'high':-4,'super':-4}[quality]
    dpi={'draft':110,'normal':175,'high':230,'super':275}[quality]
    hprinter=win32print.OpenPrinter(printer)
    hdc=None
    try:
        size=win32print.DocumentProperties(0,hprinter,printer,None,None,0)
        dm=pywintypes.DEVMODEType(max(0,size-pywintypes.DEVMODEType().Size))
        win32print.DocumentProperties(0,hprinter,printer,dm,None,win32con.DM_OUT_BUFFER)
        dm.Fields |= win32con.DM_PRINTQUALITY|win32con.DM_COLOR|win32con.DM_PAPERSIZE|win32con.DM_ORIENTATION
        dm.PrintQuality=req
        dm.Color=win32con.DMCOLOR_MONOCHROME if color=='bw' else win32con.DMCOLOR_COLOR
        dm.PaperSize=paper_const[paper]
        with fitz.open(str(pdf)) as doc:
            if not doc.page_count:raise ValueError('PDF খালি')
            first=doc[0].rect
            dm.Orientation=win32con.DMORIENT_LANDSCAPE if first.width>first.height else win32con.DMORIENT_PORTRAIT
            code=win32print.DocumentProperties(0,hprinter,printer,dm,dm,win32con.DM_IN_BUFFER|win32con.DM_OUT_BUFFER)
            if code<0:raise RuntimeError('Windows ড্রাইভার print quality গ্রহণ করেনি')
            hdc=win32gui.CreateDC('WINSPOOL',printer,dm)
            width=win32print.GetDeviceCaps(hdc,win32con.HORZRES)
            height=win32print.GetDeviceCaps(hdc,win32con.VERTRES)
            if width<=0 or height<=0:raise RuntimeError('প্রিন্টারের পেজ সাইজ শনাক্ত করা যায়নি')
            win32print.StartDoc(hdc,('Porosh Studio print',None,None,0))
            started=True
            try:
                for _ in range(int(copies)):
                    for page in doc:
                        # Bound memory (< ~30 MB per rendered page) even on 4 GB PCs.
                        scale=min(dpi/72, (7_000_000/(page.rect.width*page.rect.height))**.5)
                        pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False,colorspace=fitz.csRGB)
                        im=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
                        if color=='bw':im=im.convert('L').convert('RGB')
                        ratio=min(width/im.width,height/im.height)
                        draw_w=int(im.width*ratio);draw_h=int(im.height*ratio)
                        x=(width-draw_w)//2;y=(height-draw_h)//2
                        win32print.StartPage(hdc)
                        ImageWin.Dib(im).draw(hdc,(x,y,x+draw_w,y+draw_h))
                        win32print.EndPage(hdc)
                        del im,pix
            finally:
                win32print.EndDoc(hdc)
        return {'status':'submitted','driver_quality_applied':True,
            'detail':'Windows GDI প্রিন্ট কিউতে job-specific DEVMODE অনুরোধ পাঠানো হয়েছে; ড্রাইভার কোয়ালিটি মানছে কি না বাস্তবে যাচাই করতে হবে।'}
    finally:
        if hdc is not None:win32gui.DeleteDC(hdc)
        win32print.ClosePrinter(hprinter)
