from app import local_ip
from pathlib import Path
import qrcode
url='http://'+local_ip()+':5000/customer'
path=Path(__file__).resolve().parent/'CUSTOMER_QR.png'
qrcode.make(url).save(path)
print(f'New QR: {url} -> {path}')
print('LAN IP বদলালে QR আবার তৈরি করুন।')
