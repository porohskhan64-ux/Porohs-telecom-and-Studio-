"""Porosh Telecom & Studio: local-network printing service. Windows/Epson validation required."""
from __future__ import annotations
import io, json, os, queue, re, secrets, socket, threading, time, uuid, sqlite3, zipfile, ipaddress
from contextlib import contextmanager, closing
from collections import defaultdict, deque
from datetime import datetime
from pathlib import Path
from flask import Flask, render_template, request, jsonify, send_file, abort, g, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from PIL import Image, ImageOps
import fitz
import qrcode
from engine import IMAGE_EXT,DOC_EXT,make_photo_layout,make_document_image_pdf,make_selected_pdf,enhance_image,estimate_photo_tilt
from printer import printers,default_printer,find_program,convert_office,dispatch_pdf
from extra_tools import make_nid_sheet, pdf_action, camera_scan, skin_soften, batch_photo_sheet, scanned_image_to_pdf, scan_batch_to_pdf
from scanner import devices as scanner_devices, scan_to_file

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'; UP=DATA/'uploads'; OUT=DATA/'exports'
for folder in (DATA,UP,OUT):folder.mkdir(parents=True,exist_ok=True)
SETTINGS=ROOT/'settings.json'
DEFAULT={'shop_name':'পরশ টেলিকম অ্যান্ড স্টুডিও','phone':'013 31 46 05 84','thank_you':'ধন্যবাদ পরশ টেলিকমে প্রিন্ট করার জন্য। আশা করি আপনার দিনটা ভালো হোক।','auto_print':True,'auto_scan':True,'bw_price':2.0,'color_price':10.0,'printer':'','max_copies':10,'max_file_mb':25,'max_jobs_per_minute':3}

def config():
    if not SETTINGS.exists():return DEFAULT.copy()
    try:
        data=json.loads(SETTINGS.read_text(encoding='utf8'))
        return {**DEFAULT,**{k:v for k,v in data.items() if k in DEFAULT}}
    except (OSError,ValueError):return DEFAULT.copy()

app=Flask(__name__)
# Sign admin authentication cookies with a persistent cryptographically random secret.
SECRET_FILE=DATA/'flask-secret.key'
if not SECRET_FILE.exists():
    try:
        fd=os.open(SECRET_FILE,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w') as fp:fp.write(secrets.token_hex(32))
    except FileExistsError:pass
app.secret_key=SECRET_FILE.read_text(encoding='utf8').strip()
app.config.update(SESSION_COOKIE_HTTPONLY=True,SESSION_COOKIE_SAMESITE='Strict',PERMANENT_SESSION_LIFETIME=__import__('datetime').timedelta(hours=8))
ADMIN_AUTH=DATA/'admin_auth.json'
# The API credential is deliberately not inside settings.json, PDF metadata,
# the browser, the distributable ZIP or the automatic backup archive.
AI_KEY_FILE=DATA/'bgclear_api.key'
def get_ai_key():
    env=os.environ.get('BGCLEAR_API_KEY','').strip()
    if env:return env
    try:return AI_KEY_FILE.read_text(encoding='utf8').strip()
    except OSError:return ''

login_attempts=defaultdict(deque)

def is_admin_authenticated():
    if not is_admin_local() or not ADMIN_AUTH.exists():return False
    try:
        auth=json.loads(ADMIN_AUTH.read_text(encoding='utf8'))
        return session.get('admin_auth_id')==auth['auth_id']
    except (ValueError,KeyError,OSError):return False

def require_admin():
    if not is_admin_local():abort(403)
    if not is_admin_authenticated():abort(403)

app.config['MAX_CONTENT_LENGTH']=25*1024*1024
Image.MAX_IMAGE_PIXELS=45_000_000
jobs={}; jobs_lock=threading.Lock(); pending=queue.Queue(); rate=defaultdict(deque)
scan_jobs={}; scan_pending=queue.Queue(); scan_rate=defaultdict(deque)
owner_lock=threading.RLock(); owners={}
ai_rate=defaultdict(deque)
processing_gate=threading.BoundedSemaphore(1)

@contextmanager
def processing_slot():
    # Avoid concurrent expensive image processing on an i3 / 4 GB machine.
    if not processing_gate.acquire(timeout=12):
        raise ValueError('সার্ভারে আরেকটি কাজ চলছে। কিছুক্ষণ পরে আবার চেষ্টা করুন।')
    try:yield
    finally:processing_gate.release()

DB=DATA/'history.sqlite3'

def init_db():
    with sqlite3.connect(DB) as db:
        db.execute('CREATE TABLE IF NOT EXISTS print_jobs (id TEXT PRIMARY KEY, created TEXT, printer TEXT, copies INTEGER, pages INTEGER, color TEXT, quality TEXT, status TEXT, detail TEXT)')
        db.execute('CREATE TABLE IF NOT EXISTS file_owners (token TEXT PRIMARY KEY, owner TEXT NOT NULL, created REAL NOT NULL)')
        db.commit()
init_db()

@app.before_request
def give_private_session():
    supplied=request.cookies.get('porosh_sid','')
    g.sid=supplied if re.fullmatch(r'[a-f0-9]{32}',supplied) else secrets.token_hex(16)

@app.after_request
def response_session(resp):
    if request.cookies.get('porosh_sid')!=g.sid:
        resp.set_cookie('porosh_sid',g.sid,httponly=True,samesite='Strict',max_age=3*86400,path='/')
    resp.headers['X-Content-Type-Options']='nosniff'
    resp.headers['X-Frame-Options']='SAMEORIGIN'
    resp.headers['Referrer-Policy']='same-origin'
    resp.headers['Cache-Control']='no-store'
    return resp

def own(token):
    with owner_lock:
        owners[token]=g.sid
        with sqlite3.connect(DB) as db:
            db.execute('INSERT OR REPLACE INTO file_owners (token,owner,created) VALUES (?,?,?)',(token,g.sid,time.time()))

def allowed(token):
    if is_admin_authenticated():return True
    with owner_lock:
        who=owners.get(token)
        if who is None:
            with sqlite3.connect(DB) as db:
                row=db.execute('SELECT owner FROM file_owners WHERE token=? AND created>?',(token,time.time()-24*3600)).fetchone()
            if row:owners[token]=row[0];who=row[0]
        return who==g.sid

def check_rate(key,store,limit=3):
    now=time.monotonic(); d=store[key]
    while d and now-d[0]>60:d.popleft()
    if len(d)>=limit:raise ValueError('অনেক অনুরোধ হয়েছে; এক মিনিট পর আবার চেষ্টা করুন')
    d.append(now)


def local_ip():
    try:
        with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as s:
            s.connect(('192.0.2.1',80))
            return s.getsockname()[0]
    except OSError:
        try:return socket.gethostbyname(socket.gethostname())
        except OSError:return '127.0.0.1'

def is_admin_local():
    # Admin controls are restricted to the actual shop PC, not other LAN devices.
    try:
        address = ipaddress.ip_address(request.remote_addr or '')
        return address.is_loopback
    except ValueError:
        return False

def json_error(message,code=400):return jsonify(error=str(message)),code

def target_by_token(token,base=UP):
    if not re.fullmatch(r'[a-f0-9]{32}',str(token or '')):raise ValueError('সঠিক ফাইল আইডি নেই')
    paths=list(base.glob(token+'.*'))
    if len(paths)!=1:raise ValueError('ফাইল পাওয়া যায়নি')
    if not allowed(token):raise ValueError('এই ফাইলটি অন্য গ্রাহকের অথবা সেশন শেষ হয়েছে')
    return paths[0]

def purge_old_files():
    cutoff=time.time()-24*3600
    for folder in (UP,OUT):
        for f in folder.iterdir():
            try:
                if f.is_file() and f.stat().st_mtime<cutoff:
                    f.unlink()
                    with owner_lock:owners.pop(f.stem,None)
            except OSError:pass
    with sqlite3.connect(DB) as db:
        db.execute('DELETE FROM file_owners WHERE created<?',(cutoff,))

def cleanup_worker():
    while True:
        try:purge_old_files()
        except Exception:pass
        time.sleep(1200)

def validate_options(d):
    paper=d.get('paper','A4')
    if paper not in ('A4','A5','A6','Letter','Legal','custom'):raise ValueError('কাগজের সাইজ সঠিক নয়')
    if d.get('paper_orientation','portrait') not in ('portrait','landscape'):raise ValueError('পেজের দিক সঠিক নয়')
    return paper

def process_file(src,d,out):
    paper=validate_options(d)
    common=dict(paper=paper,paper_orientation=d.get('paper_orientation','portrait'),paper_w=d.get('paper_w',210),paper_h=d.get('paper_h',297))
    photo=src.suffix.lower() in IMAGE_EXT
    kind=d.get('mode','photo') if photo else 'document'
    if kind=='photo' and not photo:raise ValueError('ছবির লেআউটের জন্য ছবি দিন')
    if kind=='photo':
        bg_provider=d.get('background_provider','auto')
        if bg_provider not in ('auto','bgclear'):
            raise ValueError('ব্যাকগ্রাউন্ডের AI পদ্ধতি সঠিক নয়')
        wanted_bg=d.get('background','original')!='original'
        # Paid API use is limited to the local shop PC's authenticated admin.
        # Customer LAN sessions never spend the shop's API credits.
        key=''
        if wanted_bg:
            # Refuse unauthenticated/remote AI use even if key exists, so
            # customer requests cannot consume the shop's cloud quota.
            if not is_admin_authenticated():
                raise ValueError('ব্যাকগ্রাউন্ড পরিবর্তনের জন্য দোকানের কম্পিউটারে অ্যাডমিন লগইন করুন। Offline কাটিং বন্ধ।')
            key=get_ai_key()
            if not key:
                raise ValueError('BG Clear API key সেট করা নেই। /admin প্যানেলে BG Clear key বসান। Offline কাটিং বন্ধ।')
            check_rate('ai:'+g.sid,ai_rate,limit=8)
        preset=d.get('preset','passport')
        # The passport auto-layout controls the arrangement of photo tiles,
        # not the page orientation. Keep the operator's chosen paper direction.
        # Passport/stamp dimensions and rendering resolution are fixed presets;
        # custom photos can independently choose their DPI.
        dpi=300 if preset=='passport' else 150 if preset=='stamp' else d.get('photo_dpi',300)
        return make_photo_layout(src,out,preset=preset,count=d.get('count',4),photo_w=d.get('photo_w',35),photo_h=d.get('photo_h',45),image_orientation=d.get('image_orientation','portrait'),auto=d.get('enhance',True),photo_straighten=d.get('photo_straighten',False),angle=d.get('angle',0),brightness=d.get('brightness',1),contrast=d.get('contrast',1),sharpness=d.get('sharpness',1),background=d.get('background','original'),background_color=d.get('background_color','#ffffff'),background_provider=bg_provider,ai_key=key,photo_dpi=dpi,stamp_columns=d.get('stamp_columns',0),stamp_gap=d.get('stamp_gap',2),stamp_margin=d.get('stamp_margin',5),passport_row_layout=d.get('passport_auto_landscape',True),**common)
    if photo:
        return make_document_image_pdf(src,out,auto=d.get('enhance',False),deskew=d.get('deskew',False),angle=d.get('angle',0),brightness=d.get('brightness',1),contrast=d.get('contrast',1),sharpness=d.get('sharpness',1),fit=d.get('fit','contain'),**common)
    source=src
    if src.suffix.lower()!='.pdf':source=convert_office(src,OUT)
    return make_selected_pdf(source,out,pages=d.get('pages','all'),rotate=d.get('angle',0),**common)

def record_job(job):
    with jobs_lock:
        jobs[job['id']]=job
        if len(jobs)>200:
            for jid in list(jobs.keys())[:-100]:jobs.pop(jid,None)

def printer_worker():
    while True:
        jobid=pending.get()
        with jobs_lock:job=jobs.get(jobid)
        if not job:pending.task_done();continue
        if job.get('status')=='cancelled':pending.task_done();continue
        try:
            with jobs_lock:job['status']='sending'
            result=dispatch_pdf(job['path'],job['printer'],job['copies'],job['color'],job['paper'],job['quality'])
            with jobs_lock:
                job['status']='submitted';job['detail']=result['detail']
        except Exception as exc:
            with jobs_lock:job['status']='error';job['detail']=str(exc)
        finally:
            with sqlite3.connect(DB) as db:
                db.execute('INSERT OR REPLACE INTO print_jobs VALUES (?,?,?,?,?,?,?,?,?)',
                    (job['id'],job['created'],job['printer'],job['copies'],job.get('pages',0),job['color'],job['quality'],job['status'],job.get('detail','')))
            pending.task_done()

@app.get('/')
def home():
    c=config()
    return render_template('studio.html',config=c,local_url=f'http://{local_ip()}:5000',printer_names=printers(),default_name=c['printer'] or default_printer())

@app.get('/customer')
def customer():
    return render_template('customer.html',config=config(),printer_names=printers(),default_name=config()['printer'] or default_printer())

@app.get('/health')
def health():return jsonify(ok=True,service='Porosh Print',windows=os.name=='nt',sumatra=bool(find_program('sumatra')),libreoffice=bool(find_program('libreoffice')),scanner_wia=len(scanner_devices()),offline_tools=True)

@app.get('/api/network')
def network():
    # Re-evaluate on each request: local DHCP/hotspot IP may have changed.
    ip=local_ip()
    return jsonify(ip=ip,url=f'http://{ip}:5000')

@app.get('/qr.png')
def qr_code():
    img=qrcode.make(f'http://{local_ip()}:5000/customer')
    b=io.BytesIO();img.save(b,format='PNG');b.seek(0)
    return send_file(b,mimetype='image/png',max_age=0)

@app.post('/api/upload')
def upload():
    f=request.files.get('file')
    if not f or not f.filename:return json_error('একটি ফাইল নির্বাচন করুন')
    ext=Path(f.filename).suffix.lower()
    if ext not in IMAGE_EXT|DOC_EXT:return json_error('এই ফাইল টাইপ গ্রহণ করা যাচ্ছে না')
    token=uuid.uuid4().hex;path=UP/(token+ext)
    f.save(path)
    try:
        if path.stat().st_size==0:raise ValueError('খালি ফাইল গ্রহণ করা যায় না')
        if ext in IMAGE_EXT:
            with Image.open(path) as im:im.verify()
        elif ext=='.pdf':
            with fitz.open(str(path)) as doc:
                if len(doc)<1:raise ValueError('PDF-এ পৃষ্ঠা নেই')
        # LibreOffice validates and converts office documents during prepare.
    except Exception as exc:
        path.unlink(missing_ok=True)
        return json_error('ফাইলটি খুলতে সমস্যা: '+str(exc))
    own(token)
    purge_old_files()
    kind='image' if ext in IMAGE_EXT else 'document'
    return jsonify(token=token,name=Path(f.filename).name[:120],kind=kind,preview=f'/api/media/{token}' if kind=='image' else None)

@app.get('/api/media/<token>')
def media(token):
    try:path=target_by_token(token)
    except ValueError:abort(404)
    if path.suffix.lower() not in IMAGE_EXT:abort(404)
    # Image and ImageOps are imported at module level. A second import here
    # would make Image a local variable and crash before any preview is sent.
    with Image.open(path) as im:
        photo=ImageOps.exif_transpose(im).convert('RGB');photo.thumbnail((1000,1000))
        b=io.BytesIO();photo.save(b,'JPEG',quality=86);b.seek(0)
    return send_file(b,mimetype='image/jpeg',max_age=0)

@app.get('/api/photo-straight-preview/<token>')
def straight_preview(token):
    try:
        src=target_by_token(token)
        if src.suffix.lower() not in IMAGE_EXT:abort(404)
        with processing_slot():
            photo=enhance_image(src,photo_straighten=True)
            photo.thumbnail((900,1100),Image.Resampling.LANCZOS)
            b=io.BytesIO();photo.save(b,'JPEG',quality=88);b.seek(0)
        return send_file(b,mimetype='image/jpeg')
    except ValueError as exc:return json_error(exc)

@app.get('/api/photo-straight-info/<token>')
def straight_info(token):
    try:
        src=target_by_token(token)
        if src.suffix.lower() not in IMAGE_EXT:abort(404)
        with Image.open(src) as raw:
            im=ImageOps.exif_transpose(raw).convert('RGB')
            im.thumbnail((1200,1200))
        with processing_slot(): angle,status=estimate_photo_tilt(im)
        return jsonify(angle_deg=angle,status=status)
    except ValueError as exc:return json_error(exc)

@app.post('/api/prepare')
def prepare():
    try:
        d=request.get_json(silent=True) or {}
        src=target_by_token(d.get('token'))
        eid=uuid.uuid4().hex; out=OUT/(eid+'.pdf')
        with processing_slot():metadata=process_file(src,d,out)
        own(eid)
        return jsonify(export=eid,url=f'/api/pdf/{eid}',**metadata)
    except (ValueError,OverflowError,TypeError,RuntimeError,fitz.FileDataError,OSError) as exc:return json_error(exc)
    except Exception:
        app.logger.exception('Passport/print preview preparation failed')
        return json_error('প্রিন্ট প্রিভিউ তৈরি হয়নি। সার্ভারের কনসোলের Error দেখুন।',500)

@app.get('/api/pdf/<token>')
def pdf_preview(token):
    try:target=target_by_token(token,OUT)
    except ValueError:abort(404)
    if target.suffix.lower()!='.pdf':abort(404)
    return send_file(target,mimetype='application/pdf',as_attachment=False,download_name='porosh-print.pdf',max_age=0)

@app.get('/api/pdf-thumb/<token>')
def pdf_thumbnail(token):
    try:path=target_by_token(token,OUT)
    except ValueError:abort(404)
    if path.suffix.lower()!='.pdf':abort(404)
    with fitz.open(str(path)) as doc:
        if not doc.page_count:abort(404)
        page=doc[0];scale=min(1.4,950/max(page.rect.width,page.rect.height))
        pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False,colorspace=fitz.csRGB)
        image=Image.frombytes('RGB',[pix.width,pix.height],pix.samples)
        b=io.BytesIO();image.save(b,'JPEG',quality=77,optimize=True);b.seek(0)
        return send_file(b,mimetype='image/jpeg')

@app.post('/api/print')
def print_submit():
    try:
        c=config();d=request.get_json(silent=True) or {}
        token=d.get('export');out=target_by_token(token,OUT)
        if out.suffix.lower()!='.pdf':raise ValueError('আগে PDF প্রিভিউ তৈরি করুন')
        if not c['auto_print'] and not is_admin_authenticated():raise ValueError('অটোমেটিক প্রিন্ট সাময়িকভাবে বন্ধ আছে')
        ip=request.remote_addr or 'unknown'
        now=time.monotonic(); window=rate[ip]
        while window and now-window[0]>60:window.popleft()
        if len(window)>=int(c['max_jobs_per_minute']):raise ValueError('এক মিনিটে অনেক প্রিন্ট অনুরোধ হয়েছে; একটু অপেক্ষা করুন')
        copies=int(d.get('copies',1))
        if not 1<=copies<=min(int(c['max_copies']),10):raise ValueError('কপির সংখ্যা অনুমোদিত সীমার বাইরে')
        with fitz.open(str(out)) as doc:
            if len(doc)*copies>100:raise ValueError('এক অনুরোধে সর্বোচ্চ ১০০ পৃষ্ঠা প্রিন্ট করা যাবে')
        printer = d.get('printer') or c['printer'] or default_printer()
        if not printer:raise ValueError('Windows-এ ডিফল্ট প্রিন্টার সেট করুন')
        if printer not in printers():raise ValueError('এই প্রিন্টার Windows-এ নেই')
        paper=d.get('paper','A4');color=d.get('color','color');quality=d.get('quality','normal')
        if paper not in ('A4','A5','A6','Letter','Legal','custom') or color not in ('color','bw') or quality not in ('draft','normal','high','super'):raise ValueError('প্রিন্ট অপশন সঠিক নয়')
        jid=uuid.uuid4().hex
        with fitz.open(str(out)) as doc:page_count=doc.page_count
        job={'id':jid,'status':'queued','created':datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
             'path':str(out),'printer':printer,'pages':page_count,'copies':copies,'paper':paper,'color':color,'quality':quality,'detail':'প্রিন্ট কিউতে অপেক্ষা করছে'}
        record_job(job);own(jid);window.append(now);pending.put(jid)
        return jsonify(id=jid,status='queued',url=f'/job/{jid}')
    except (ValueError,TypeError,RuntimeError,OSError) as exc:return json_error(exc)

@app.post('/api/job/<jid>/cancel')
def cancel_job(jid):
    if not allowed(jid):abort(404)
    with jobs_lock:
        job=jobs.get(jid)
        if not job:abort(404)
        if job['status']!='queued':
            return json_error('শুধু কিউতে অপেক্ষারত কাজ বাতিল করা যায়',409)
        job['status']='cancelled'
        job['detail']='গ্রাহক প্রিন্টের অনুরোধ বাতিল করেছেন'
    return jsonify(id=jid,status='cancelled')


@app.post('/api/estimate')
def estimate():
    try:
        d=request.get_json(silent=True) or {}
        copies=int(d.get('copies',1))
        pages=int(d.get('pages',1))
        if not (1<=copies<=10 and 1<=pages<=100 and copies*pages<=100):
            raise ValueError('কপি বা পৃষ্ঠার সংখ্যা সঠিক নয়')
        color=d.get('color','bw')
        if color not in ('bw','color'):raise ValueError('কালার অপশন সঠিক নয়')
        c=config()
        unit=float(c['color_price'] if color=='color' else c['bw_price'])
        return jsonify(pages=pages,copies=copies,color=color,unit_price=unit,
                       total=round(pages*copies*unit,2),currency='BDT',
                       note='এটি আনুমানিক মূল্য, চূড়ান্ত বিল নয়')
    except (ValueError,TypeError,OverflowError) as exc:return json_error(exc)


@app.get('/api/job/<jid>')
def job_api(jid):
    with jobs_lock: j=jobs.get(jid)
    if not j or not allowed(jid):abort(404)
    return jsonify(id=jid,status=j['status'],detail=j.get('detail',''),created=j['created'])

@app.get('/job/<jid>')
def job_page(jid):
    with jobs_lock:exists=jid in jobs
    if not exists or not allowed(jid):abort(404)
    return render_template('job.html',jid=jid,config=config())

@app.route('/admin/login', methods=['GET','POST'])
def admin_login():
    if not is_admin_local():abort(403)
    error=''
    if request.method=='POST':
        if request.form.get('csrf')!=g.sid:abort(403)
        now=time.monotonic(); q=login_attempts[request.remote_addr]
        while q and now-q[0]>900:q.popleft()
        if len(q)>=8:
            error='অনেকবার ভুল চেষ্টা হয়েছে। ১৫ মিনিট পরে আবার চেষ্টা করুন।'
        else:
            password=request.form.get('password','')
            if not ADMIN_AUTH.exists():
                confirm=request.form.get('confirm','')
                if len(password)<12 or len(password)>128 or password!=confirm:
                    error='প্রথমবার ১২–১২৮ অক্ষরের শক্তিশালী পাসওয়ার্ড দিন; দুইবার একই লিখুন।'
                else:
                    auth={'auth_id':secrets.token_hex(16),'password_hash':generate_password_hash(password,method='scrypt')}
                    try:
                        fd=os.open(ADMIN_AUTH,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
                        with os.fdopen(fd,'w',encoding='utf8') as f:json.dump(auth,f)
                    except FileExistsError:
                        error='পাসওয়ার্ড ইতিমধ্যে সেট করা হয়েছে। এবার লগইন করুন।'
                    else:
                        session.clear();session['admin_auth_id']=auth['auth_id'];session.permanent=True
                        login_attempts.pop(request.remote_addr,None)
                        return redirect(url_for('admin'))
            else:
                try:auth=json.loads(ADMIN_AUTH.read_text(encoding='utf8'))
                except (OSError,ValueError,KeyError):abort(500)
                if check_password_hash(auth['password_hash'],password):
                    session.clear();session['admin_auth_id']=auth['auth_id'];session.permanent=True
                    login_attempts.pop(request.remote_addr,None)
                    return redirect(url_for('admin'))
                q.append(now);error='পাসওয়ার্ড সঠিক নয়।'
    return render_template('admin_login.html',setup=not ADMIN_AUTH.exists(),csrf=g.sid,error=error)

@app.post('/admin/logout')
def admin_logout():
    require_admin()
    if request.form.get('csrf')!=g.sid:abort(403)
    session.clear();return redirect(url_for('admin_login'))

@app.get('/admin')
def admin():
    if not is_admin_local():abort(403)
    if not is_admin_authenticated():return redirect(url_for('admin_login'))
    with sqlite3.connect(DB) as db:
        db.row_factory=sqlite3.Row
        stats=[dict(r) for r in db.execute('SELECT * FROM print_jobs ORDER BY created DESC LIMIT 50')]
        totals=db.execute("SELECT COUNT(*),COALESCE(SUM(pages*copies),0) FROM print_jobs WHERE status='submitted'").fetchone()
    c=config()
    for j in stats:
        j['estimate']=(float(c['color_price']) if j['color']=='color' else float(c['bw_price']))*int(j['copies'])*int(j['pages'])
    return render_template('admin.html',settings=c,ai_configured=bool(get_ai_key()),ai_sandbox=False,ai_env_configured=bool(os.environ.get('BGCLEAR_API_KEY','').strip()),printer_names=printers(),jobs=stats,totals=totals,csrf=g.sid,scanner_names=scanner_devices())

@app.post('/admin/settings')
def update_settings():
    require_admin()
    if request.form.get('csrf')!=g.sid:abort(403)
    d=request.form;c=config()
    c['shop_name']=d.get('shop_name',c['shop_name'])[:80]
    c['phone']=d.get('phone',c['phone'])[:32]
    c['thank_you']=d.get('thank_you',c['thank_you'])[:250]
    c['auto_print']='auto_print' in d
    c['auto_scan']='auto_scan' in d
    try:
        c['bw_price']=min(1000,max(0,float(d.get('bw_price',c['bw_price']))))
        c['color_price']=min(1000,max(0,float(d.get('color_price',c['color_price']))))
    except (ValueError,TypeError):pass
    requested=d.get('printer','')
    c['printer']=requested if requested in printers() else ''
    SETTINGS.write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding='utf8')
    return admin()


@app.post('/admin/ai-key')
def update_ai_key():
    require_admin()
    if request.form.get('csrf')!=g.sid:abort(403)
    action=request.form.get('action','save')
    if action=='remove':
        AI_KEY_FILE.unlink(missing_ok=True)
        return redirect(url_for('admin'))
    if action!='save':return json_error('অবৈধ AI সেটিংস',400)
    new_key=request.form.get('bgclear_api_key','').strip()
    if not 10<=len(new_key)<=300 or any(ch.isspace() or ord(ch)<33 or ord(ch)>126 for ch in new_key):
        return json_error('API key ১০–৩০০ অক্ষরের একটানা ASCII টোকেন হতে হবে।',400)
    # Write with restrictive permissions; atomic replacement prevents partial keys.
    tmp=DATA/('key-tmp-'+uuid.uuid4().hex)
    try:
        fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
        with os.fdopen(fd,'w',encoding='utf8') as fp:fp.write(new_key)
        os.replace(tmp,AI_KEY_FILE)
    finally:
        tmp.unlink(missing_ok=True)
    return redirect(url_for('admin'))


# Each customer keeps their own uploaded files, exports, scanner jobs and print status.
@app.post('/api/batch-photo')
def batch_photo():
    try:
        d=request.get_json(silent=True) or {}
        tokens=d.get('tokens',[])
        if not isinstance(tokens,list) or not 1<=len(tokens)<=12:
            raise ValueError('Batch photo-তে ১–১২টি ছবি দিন')
        paths=[target_by_token(t) for t in tokens]
        eid=uuid.uuid4().hex;dst=OUT/(eid+'.pdf')
        with processing_slot():info=batch_photo_sheet(paths,dst,d.get('preset','passport'),d.get('copies_each',2))
        own(eid)
        return jsonify(export=eid,url='/api/pdf/'+eid,**info)
    except (ValueError,RuntimeError,TypeError,OSError) as exc:return json_error(exc)

@app.post('/api/nid')
def nid_prepare():
    try:
        d=request.get_json(silent=True) or {}
        a=target_by_token(d.get('front')); b=target_by_token(d.get('back'))
        if a.suffix.lower() not in IMAGE_EXT or b.suffix.lower() not in IMAGE_EXT:
            raise ValueError('NID সামনে ও পেছনের ছবি দিন')
        eid=uuid.uuid4().hex;dst=OUT/(eid+'.pdf')
        with processing_slot():info=make_nid_sheet(a,b,dst,auto_crop=bool(d.get('auto_crop',True)),enhance=bool(d.get('enhance',True)))
        own(eid)
        return jsonify(export=eid,url='/api/pdf/'+eid,**info)
    except (ValueError,RuntimeError,TypeError,OSError) as exc:return json_error(exc)


@app.post('/api/combine-prepared')
def combine_prepared():
    try:
        d=request.get_json(silent=True) or {}; tokens=d.get('exports',[])
        if not isinstance(tokens,list) or not 1<=len(tokens)<=20:raise ValueError('১–২০টি প্রস্তুত ফাইল একত্র করুন')
        paths=[target_by_token(t,OUT) for t in tokens]
        eid=uuid.uuid4().hex; dst=OUT/(eid+'.pdf'); merged=fitz.open()
        try:
            for path in paths:
                with fitz.open(str(path)) as doc: merged.insert_pdf(doc)
            if merged.page_count>100:raise ValueError('একসঙ্গে সর্বোচ্চ ১০০ পৃষ্ঠা')
            merged.save(str(dst),garbage=3,deflate=True)
        finally:merged.close()
        own(eid)
        with fitz.open(str(dst)) as doc: pages=doc.page_count
        return jsonify(export=eid,url='/api/pdf/'+eid,pages=pages,note='একাধিক ফাইল এক PDF-এ সাজানো হয়েছে।')
    except (ValueError,RuntimeError,TypeError,OSError,fitz.FileDataError) as exc:return json_error(exc)

@app.post('/api/pdf-tools')
def pdf_tools():
    try:
        d=request.get_json(silent=True) or {};tokens=d.get('tokens',[])
        if not isinstance(tokens,list) or not 1<=len(tokens)<=10:raise ValueError('১–১০টি PDF ফাইল বেছে নিন')
        paths=[target_by_token(t) for t in tokens]
        if any(p.suffix.lower()!='.pdf' for p in paths):raise ValueError('শুধু PDF ফাইল দিন')
        eid=uuid.uuid4().hex;dst=OUT/(eid+'.pdf')
        with processing_slot():info=pdf_action(paths,dst,d.get('action','merge'),d.get('pages','all'),d.get('rotation',90))
        own(eid)
        return jsonify(export=eid,url='/api/pdf/'+eid,**info)
    except (ValueError,RuntimeError,TypeError,OSError,fitz.FileDataError) as exc:return json_error(exc)

@app.post('/api/camera-scan')
def phone_scan():
    try:
        d=request.get_json(silent=True) or {};src=target_by_token(d.get('token'))
        if src.suffix.lower() not in IMAGE_EXT:raise ValueError('ক্যামেরা থেকে ছবি তুলুন')
        token=uuid.uuid4().hex;dst=UP/(token+'.jpg')
        with processing_slot():info=camera_scan(src,dst,d.get('mode','color'))
        own(token)
        eid=uuid.uuid4().hex;pdf=OUT/(eid+'.pdf')
        with processing_slot():detail=make_document_image_pdf(dst,pdf,paper='A4')
        own(eid)
        return jsonify(token=token,preview='/api/media/'+token,export=eid,url='/api/pdf/'+eid,**detail,**info)
    except (ValueError,RuntimeError,TypeError,OSError) as exc:return json_error(exc)

@app.post('/api/scan-crop')
def scan_crop_pdf():
    try:
        d=request.get_json(silent=True) or {}
        src=target_by_token(d.get('token'))
        if src.suffix.lower() not in IMAGE_EXT:raise ValueError('স্ক্যানের ছবি নির্বাচন করুন')
        eid=uuid.uuid4().hex;dst=OUT/(eid+'.pdf')
        try:
            with processing_slot():
                info=scanned_image_to_pdf(src,dst,rect=d.get('rect'),paper=d.get('paper','A4'),
                    orientation=d.get('orientation','portrait'),custom_w=d.get('custom_w',210),
                    custom_h=d.get('custom_h',297),fit=d.get('fit','contain'),mode=d.get('mode','color'))
        except Exception:
            dst.unlink(missing_ok=True)
            raise
        own(eid)
        return jsonify(export=eid,url='/api/pdf/'+eid,**info)
    except (ValueError,RuntimeError,TypeError,OSError,OverflowError,Image.DecompressionBombError) as exc:
        return json_error(exc)

@app.post('/api/scan-sheet')
def scan_sheet_pdf():
    try:
        d=request.get_json(silent=True) or {}
        scans=d.get('scans')
        if not isinstance(scans,list) or not 1 <= len(scans) <= 12:
            raise ValueError('একসঙ্গে ১–১২টি স্ক্যান যোগ করুন')
        items=[]
        for item in scans:
            if not isinstance(item,dict):raise ValueError('স্ক্যানের তথ্য সঠিক নয়')
            src=target_by_token(item.get('token'))
            if src.suffix.lower() not in IMAGE_EXT:
                raise ValueError('শুধু ছবি স্ক্যান হিসেবে ব্যবহার করুন')
            items.append((src,item.get('rect',[0,0,1,1])))
        eid=uuid.uuid4().hex;dest=OUT/(eid+'.pdf')
        try:
            with processing_slot():
                info=scan_batch_to_pdf(items,dest,paper=d.get('paper','A4'),
                    orientation=d.get('orientation','portrait'),
                    custom_w=d.get('custom_w',210),custom_h=d.get('custom_h',297),
                    fit=d.get('fit','contain'),mode=d.get('mode','color'),
                    layout=d.get('layout','one_page'),columns=d.get('columns',0))
        except Exception:
            dest.unlink(missing_ok=True)
            raise
        own(eid)
        return jsonify(export=eid,url='/api/pdf/'+eid,**info)
    except (ValueError,RuntimeError,TypeError,OSError,OverflowError,Image.DecompressionBombError) as exc:
        return json_error(exc)

@app.post('/api/retouch')
def retouch():
    try:
        d=request.get_json(silent=True) or {};src=target_by_token(d.get('token'))
        if src.suffix.lower() not in IMAGE_EXT:raise ValueError('একটি ছবি দিন')
        with Image.open(src) as raw:
            from PIL import Image, ImageOps
            image=ImageOps.exif_transpose(raw).convert('RGB');image.thumbnail((2400,2400))
        strength=float(d.get('strength',.45))
        with processing_slot():final=skin_soften(image,strength)
        token=uuid.uuid4().hex;dst=UP/(token+'.jpg')
        final.save(dst,'JPEG',quality=93,optimize=True);own(token)
        return jsonify(token=token,preview='/api/media/'+token,kind='image',name='Soft retouch.jpg',note='Non-generative face softness; চেহারা অপরিবর্তিত।')
    except (ValueError,RuntimeError,TypeError,OSError) as exc:return json_error(exc)

@app.get('/api/scanners')
def scanner_list():
    return jsonify(devices=scanner_devices(),supported=os.name=='nt',backend='Windows WIA')

def scan_worker():
    while True:
        jid=scan_pending.get()
        with jobs_lock:j=scan_jobs.get(jid)
        if not j:scan_pending.task_done();continue
        try:
            j['status']='scanning'
            token=uuid.uuid4().hex;dst=UP/(token+'.jpg')
            scan_to_file(dst,j['dpi'],j['device'])
            with Image.open(dst) as im:im.verify()
            with owner_lock:
                owners[token]=j['owner']
                with sqlite3.connect(DB) as db:
                    db.execute('INSERT OR REPLACE INTO file_owners VALUES (?,?,?)',(token,j['owner'],time.time()))
            j['token']=token;j['preview']='/api/media/'+token;j['status']='ready'
        except Exception as exc:
            j['status']='error';j['detail']=str(exc)
        finally:scan_pending.task_done()

@app.post('/api/scanners/scan')
def scan_request():
    try:
        if not config().get('auto_scan',True) and not is_admin_authenticated():raise ValueError('দোকানের স্ক্যানার আপাতত বন্ধ')
        if scan_pending.qsize()>4:raise ValueError('স্ক্যানারের কিউ পূর্ণ')
        check_rate(g.sid,scan_rate,2)
        d=request.get_json(silent=True) or {}
        dpi=int(d.get('dpi',200));idx=int(d.get('device',1))
        if dpi not in (100,150,200,300):raise ValueError('স্ক্যান DPI সঠিক নয়')
        if idx not in [v['index'] for v in scanner_devices()]:raise ValueError('Windows WIA স্ক্যানার পাওয়া যায়নি')
        jid=uuid.uuid4().hex
        with jobs_lock:scan_jobs[jid]={'id':jid,'owner':g.sid,'status':'queued','dpi':dpi,'device':idx,'detail':'স্ক্যান কিউতে আছে'}
        own(jid);scan_pending.put(jid)
        return jsonify(id=jid,status='queued')
    except (ValueError,RuntimeError,TypeError,OSError) as exc:return json_error(exc)

@app.get('/api/scanners/job/<jid>')
def scanner_job(jid):
    if not allowed(jid):abort(404)
    with jobs_lock:j=scan_jobs.get(jid)
    if not j:abort(404)
    return jsonify({k:v for k,v in j.items() if k not in ('owner',)})

@app.post('/admin/backup')
def download_backup():
    require_admin()
    if request.form.get('csrf')!=g.sid:abort(403)
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w',compression=zipfile.ZIP_DEFLATED) as z:
        if SETTINGS.exists():z.write(SETTINGS,'settings.json')
        # SQLite online backup avoids copying an inconsistent database mid-transaction.
        if DB.exists():
            tmp=DATA/('backup-'+uuid.uuid4().hex+'.sqlite3')
            try:
                # `with connect()` commits transactions but does NOT close the handle.
                # Explicitly close both connections before reading/deleting on Windows.
                with closing(sqlite3.connect(DB)) as src, closing(sqlite3.connect(tmp)) as dst:
                    src.backup(dst)
                z.writestr('history.sqlite3',tmp.read_bytes())
            finally:
                # Windows antivirus/indexers can momentarily lock the temp file.
                # A failed optional cleanup must not turn a valid ZIP into HTTP 500.
                for attempt in range(5):
                    try:
                        tmp.unlink(missing_ok=True)
                        break
                    except PermissionError:
                        if attempt<4:time.sleep(.15)
        if ADMIN_AUTH.exists():z.write(ADMIN_AUTH,'admin_auth.json')
        if SECRET_FILE.exists():z.write(SECRET_FILE,'flask-secret.key')
    b.seek(0)
    return send_file(b,mimetype='application/zip',as_attachment=True,download_name='porosh-settings-history-backup.zip')

@app.errorhandler(413)
def too_large(e):return json_error('২৫ MB-এর বেশি ফাইল গ্রহণ করা যাবে না',413)

if __name__=='__main__':
    threading.Thread(target=printer_worker,daemon=True).start()
    threading.Thread(target=scan_worker,daemon=True).start()
    threading.Thread(target=cleanup_worker,daemon=True).start()
    print('Porosh Studio / এই কম্পিউটারে: http://127.0.0.1:5000')
    print('মোবাইল একই Wi-Fi-তে: http://'+local_ip()+':5000')
    print('অন্য কম্পিউটার/ইন্টারনেটে নিরাপত্তা ছাড়া খুলবেন না।')
    app.run(host='0.0.0.0',port=5000,debug=False,threaded=True,use_reloader=False)
