@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Installing Python packages...
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
echo.
echo Done. If there was no error, run START_SERVER.bat
pause
