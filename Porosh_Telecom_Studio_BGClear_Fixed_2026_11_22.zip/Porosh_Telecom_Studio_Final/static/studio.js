'use strict';
const $=id=>document.getElementById(id);
let mode='photo', uploaded=null, exportId=null;
let currentUploadId=0;
const msg=(s,err=false)=>{ $('notice').textContent=s; $('notice').style.borderLeftColor=err?'#db453f':'#3182e6'; };
function selectTab(tab){
  if(tab==='qr'){$('mainColumns').hidden=true;$('qrSection').hidden=false;refreshQR();}
  else{$('mainColumns').hidden=false;$('qrSection').hidden=true;mode=tab;}
  for(const id of ['photoTab','docTab','qrTab'])$(id).classList.toggle('active',id===(tab==='photo'?'photoTab':tab==='qr'?'qrTab':'docTab'));
  $('photoOptions').hidden=mode!=='photo';$('docOptions').hidden=mode!=='document';
  document.querySelectorAll('.docDeskew').forEach(x=>x.hidden=mode!=='document');
  document.querySelectorAll('.photoStraighten').forEach(x=>x.hidden=mode!=='photo'||(x.id==='straightCompare'&&(!uploaded||uploaded.kind!=='image')));
  $('uploadText').textContent=mode==='photo'?'পাসপোর্ট, স্ট্যাম্প বা কাস্টম ছবি আপলোড':'PDF, Word অথবা কাগজের ছবি আপলোড';
  $('previewDescription').textContent=mode==='photo'?'ছবিগুলো প্রিন্টের পৃষ্ঠায় সাজানোর পর এখানে দেখে নিন':'ডকুমেন্টের প্রিন্ট প্রিভিউ এখানে দেখে নিন';
  $('downloadBtn').textContent=mode==='photo'?'↧ প্রিন্ট ফাইল খুলুন / সেভ করুন':'↧ প্রিন্ট PDF খুলুন / সেভ করুন';
  if(uploaded && mode==='photo' && uploaded.kind!=='image')msg('ফটো স্টুডিওর জন্য JPG/PNG/WEBP ছবি বেছে নিন',true);
  exportId=null;$('printBtn').disabled=true;
}
function changePreset(){
  const v=$('preset').value;
  if(v==='passport'){$('photo_w').value=38.1;$('photo_h').value=48.26;$('photo_dpi').value='300';}
  else if(v==='stamp'){$('photo_w').value=25;$('photo_h').value=30;$('photo_dpi').value='150';}
  $('photo_w').disabled=v!=='custom';$('photo_h').disabled=v!=='custom';$('photo_dpi').disabled=v!=='custom';
  $('stampLayout').hidden=v!=='stamp';$('passportAutoLine').hidden=v!=='passport';
  $('photoDimensionNote').textContent=v==='passport'?'পাসপোর্ট: ১.৫ × ১.৯ ইঞ্চি, ৩০০ DPI = ৪৫০ × ৫৭০ পিক্সেল।':
     v==='stamp'?'স্ট্যাম্প: ২৫ × ৩০ মিমি, ১৫০ DPI ≈ ১৪৮ × ১৭৭ পিক্সেল। DPI বদলালেই শুধু দৈহিক মাপ বদলায় না।':'কাস্টম: ছবির মাপ এবং DPI আপনি ঠিক করবেন।';
  invalidatePreview();
}
function convertToStamp(){
 $('preset').value='stamp';changePreset();saveEdit();
 msg('স্ট্যাম্প সাইজ (২৫ × ৩০ মিমি, ১৫০ DPI) নির্বাচন হয়েছে। নিচে কপি, কলাম ও ফাঁক সাজিয়ে নতুন প্রিভিউ তৈরি করুন।');
}
function invalidatePreview(){
 const hadPreview=Boolean(exportId);
 exportId=null;$('printBtn').disabled=true;$('downloadBtn').hidden=true;
 if(hadPreview)$('previewBox').innerHTML='<div class="placeholder"><span>▤</span><strong>সেটিংস বদলেছে</strong><p>নতুন PDF প্রিভিউ তৈরি করুন।</p></div>';
 if(uploaded)$('result').textContent='সেটিংস বদলেছে — প্রিন্টের আগে নতুন PDF প্রিভিউ তৈরি করুন।';
}
$('passport_auto_landscape').addEventListener('change',()=>invalidatePreview());
function stepCount(n){$('count').value=Math.max(1,Math.min(60,Number($('count').value||4)+n));}
function toggleCustom(){$('customDimensions').hidden=$('paper').value!=='custom';}
const inp=$('fileInput');
$('dropzone').addEventListener('dragover',e=>{e.preventDefault();$('dropzone').style.borderColor='#1165d4'});
$('dropzone').addEventListener('dragleave',()=>{$('dropzone').style.borderColor=''});
$('dropzone').addEventListener('drop',e=>{e.preventDefault();$('dropzone').style.borderColor='';if(e.dataTransfer.files[0])upload(e.dataTransfer.files[0]);});
inp.addEventListener('change',()=>{if(inp.files[0])upload(inp.files[0]);});
async function jsonPost(url,obj){
 let r;
 try{r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(obj)});}
 catch(e){throw Error('সার্ভারে সংযোগ হচ্ছে না। START_SERVER চালু আছে কি না দেখুন।');}
 const type=(r.headers.get('content-type')||'').toLowerCase();
 if(!type.includes('application/json')){
   throw Error(`সার্ভার থেকে প্রত্যাশিত তথ্য আসেনি (HTTP ${r.status})। সার্ভারের কনসোলে Error দেখুন এবং সফটওয়্যার পুনরায় চালু করুন।`);
 }
 let j;
 try{j=await r.json();}catch(e){throw Error('সার্ভারের উত্তর অসম্পূর্ণ। আবার চেষ্টা করুন।');}
 if(!r.ok)throw Error(j.error||`কাজটি করা যায়নি (HTTP ${r.status})`);
 return j;
}
async function upload(file){
 const uploadId=++currentUploadId;
 try{
   msg('ফাইল আপলোড হচ্ছে...');let form=new FormData();form.append('file',file);
   let r=await fetch('/api/upload',{method:'POST',body:form});let j=await r.json();if(!r.ok)throw Error(j.error||'আপলোড ব্যর্থ');
   if(uploadId!==currentUploadId)return; // A later upload has taken over.
   uploaded=j;exportId=null;$('printBtn').disabled=true;$('downloadBtn').hidden=true;
   $('filename').hidden=false;$('filename').textContent='✓ '+j.name;
   if(j.kind==='image'){
     $('straightCompare').hidden=mode!=='photo';
     $('straightInfo').textContent='মূল ছবি ও অটো সোজা প্রিভিউ লোড হচ্ছে...';
     $('beforeStraight').src=j.preview+'?original='+uploadId;
     $('afterStraight').removeAttribute('src');
     $('beforeStraight').onerror=()=>{if(uploadId===currentUploadId)$('straightInfo').textContent='মূল ছবির প্রিভিউ লোড হয়নি। সার্ভারের Error দেখুন।';};
     $('previewBox').innerHTML='';let img=document.createElement('img');img.alt='আপলোড করা মূল ছবি';img.src=j.preview;
     img.onerror=()=>{if(uploadId===currentUploadId)$('previewBox').textContent='ছবির প্রিভিউ লোড হয়নি। সার্ভারের Error দেখুন।';};
     $('previewBox').append(img);
   }else{
     $('straightCompare').hidden=true;
     $('beforeStraight').removeAttribute('src');$('afterStraight').removeAttribute('src');
     $('previewBox').innerHTML='<div class="placeholder"><span>📄</span><strong>ফাইল আপলোড হয়েছে</strong><p>প্রিভিউ তৈরি করুন।</p></div>';
   }
   if(j.kind==='document' && mode==='photo')selectTab('document');
   msg(j.kind==='image'?'ছবি আপলোড হয়েছে। আগে-পরে অটো প্রিভিউ নিচেই দেখুন; এরপর প্রিন্ট প্রিভিউ তৈরি করুন।':'ফাইল আপলোড হয়েছে। এখন সেটিংস দেখে প্রিভিউ তৈরি করুন।');
   if(j.kind==='image'&&mode==='photo')void showStraightCompare();
 }catch(e){if(uploadId===currentUploadId)msg('ত্রুটি: '+e.message,true)}
}
async function showStraightCompare(){
 if(!uploaded||uploaded.kind!=='image')return msg('আগে একটি ছবি আপলোড করুন',true);
 const token=uploaded.token,info=$('straightInfo');
 info.textContent='আগে-পরে ছবির প্রিভিউ তৈরি হচ্ছে...';
 try{
  const r=await fetch('/api/photo-straight-info/'+encodeURIComponent(token),{cache:'no-store'});
  const d=await r.json();if(!r.ok)throw Error(d.error||'মুখের অবস্থান শনাক্ত করা যায়নি');
  if(!uploaded||token!==uploaded.token)return;
  const after=$('afterStraight');
  await new Promise((resolve,reject)=>{
    after.onload=()=>resolve();
    after.onerror=()=>reject(Error('ছবি লোড হয়নি (সার্ভার প্রিভিউ ত্রুটি)'));
    after.src='/api/photo-straight-preview/'+encodeURIComponent(token)+'?v='+Date.now();
  });
  if(!uploaded||token!==uploaded.token)return;
  if(d.status==='detected')info.textContent='✓ অটো সোজা হয়েছে: '+Math.abs(d.angle_deg).toFixed(1)+'°। আগে-পরে মিলিয়ে দেখুন।';
  else if(d.status==='already_level')info.textContent='✓ চোখের রেখা আগে থেকেই সোজা; ছবি ঘোরানো হয়নি।';
  else info.textContent='✓ নিশ্চিতভাবে দুই চোখ পাওয়া যায়নি; মুখ আন্দাজে ঘোরানো হয়নি। আগে-পরে একই দেখাতে পারে।';
 }catch(e){if(uploaded&&token===uploaded.token)info.textContent='আগে-পরে প্রিভিউ পাওয়া যায়নি: '+e.message;}
}
function options(){
 let keys=['preset','count','photo_w','photo_h','photo_dpi','stamp_columns','stamp_gap','stamp_margin','image_orientation','background','background_provider','background_color','paper','paper_orientation','paper_w','paper_h','angle','brightness','contrast','sharpness','pages','fit'];
 let o={token:uploaded.token,mode:mode};for(let k of keys)o[k]=$(k).value;
 o.passport_auto_landscape=$('passport_auto_landscape').checked && mode==='photo';
 o.enhance=$('enhance').checked;o.photo_straighten=$('photo_straighten').checked && mode==='photo';o.deskew=$('deskew').checked && mode==='document';return o;
}
async function prepare(){
 if(!uploaded)return msg('আগে ফাইল নির্বাচন করুন',true);
 if(mode==='photo'&&uploaded.kind!=='image')return msg('ফটো প্রিন্টের জন্য ছবি আপলোড করুন',true);
 try{
  $('prepareBtn').disabled=true;
  const aiBackground=mode==='photo' && $('background').value!=='original';
  msg(aiBackground
    ? 'BG Clear অনলাইন AI-তে ব্যাকগ্রাউন্ড প্রসেস করে প্রিভিউ তৈরি হচ্ছে। ফ্রি Preview-তে Watermark নেই...'
    : mode==='photo'
      ? 'ছবি প্রিন্টের পৃষ্ঠায় সাজিয়ে প্রিভিউ তৈরি হচ্ছে...'
      : 'ডকুমেন্টের প্রিন্ট প্রিভিউ তৈরি হচ্ছে...');
  const d=await jsonPost('/api/prepare',options());exportId=d.export;
  $('previewBox').innerHTML='';let iframe=document.createElement('iframe');iframe.src=d.url+'#toolbar=1&navpanes=0';iframe.title='প্রিন্টের PDF প্রিভিউ';$('previewBox').append(iframe);
  $('downloadBtn').hidden=false;$('downloadBtn').href=d.url;$('printBtn').disabled=false;
  let resultText=`✓ ${d.pages} পৃষ্ঠা তৈরি | কাগজ: ${d.paper_mm.map(x=>x.toFixed(1)).join(' × ')} মিমি`+(d.copies?' | ছবির সংখ্যা: '+d.copies:'');
  if(mode==='photo' && d.photo_mm){resultText+=` | ছবির মাপ: ${d.photo_mm.map(x=>Number(x).toFixed(2)).join(' × ')} মিমি`+` | ${d.photo_dpi} DPI`;}
  if(mode==='photo' && $('photo_straighten').checked){
    if(d.photo_alignment_status==='detected')resultText+=` | ছবি ${Math.abs(d.photo_angle_deg).toFixed(1)}° সোজা করা হয়েছে`;
    else if(d.photo_alignment_status==='already_level')resultText+=' | ছবির মুখ সোজা শনাক্ত হয়েছে';
    else resultText+=' | নিশ্চিত চোখের অবস্থান পাওয়া যায়নি; দরকারে ম্যানুয়াল ঘোরান';
  }
  if(mode==='photo' && d.background_method==='bgclear_online_ai_preview')resultText+=' | ✨ BG Clear Online AI (Free Preview)';

  if(mode==='photo'&&d.smart_crop_status==='face_detected')resultText+=' | Face-aware crop';else if(mode==='photo')resultText+=' | সাধারণ ক্রপ (মুখ নিশ্চিত নয়)';$('result').textContent=resultText;
  msg('প্রিভিউ তৈরি হয়েছে। দেখে নিশ্চিত হলে প্রিন্ট করুন।');
 }catch(e){msg('ত্রুটি: '+e.message,true)}finally{$('prepareBtn').disabled=false;}
}
async function submitPrint(){
 if(!exportId)return msg('প্রথমে প্রিভিউ তৈরি করুন',true);
 if(!confirm('প্রিভিউ ও কাগজের মাপ পরীক্ষা করেছেন? এখন প্রিন্ট কমান্ড পাঠানো হবে।'))return;
 try{
  $('printBtn').disabled=true;msg('প্রিন্ট কিউতে পাঠানো হচ্ছে...');
  let d=await jsonPost('/api/print',{export:exportId,printer:$('printer').value,copies:$('copies').value,color:$('color').value,quality:$('quality').value,paper:$('paper').value});
  window.location.href=d.url;
 }catch(e){msg('ত্রুটি: '+e.message,true);$('printBtn').disabled=false;}
}
async function refreshQR(){
 try{
  const res=await fetch('/api/network',{cache:'no-store'});
  if(!res.ok)throw Error('নেটওয়ার্ক তথ্য পাওয়া যায়নি');
  const info=await res.json();
  $('liveAddress').textContent=info.url;
  $('liveQr').src='/qr.png?refresh='+Date.now();
 }catch(e){msg('QR আপডেটে সমস্যা: '+e.message,true);}
}
changePreset();selectTab('photo');

// Lightweight edit-setting history. This stores choices, not large image buffers.
const historyIds=['preset','count','photo_w','photo_h','photo_dpi','stamp_columns','stamp_gap','stamp_margin','passport_auto_landscape','background','background_provider','background_color','image_orientation','angle','brightness','contrast','sharpness','enhance','photo_straighten','deskew','paper','paper_orientation','paper_w','paper_h'];
let settingsHistory=[],historyAt=-1;
function settingState(){const o={};for(const id of historyIds){let node=$(id);if(node)o[id]=node.type==='checkbox'?node.checked:node.value;}return o}
function saveEdit(){const o=settingState();if(JSON.stringify(o)===JSON.stringify(settingsHistory[historyAt]))return;settingsHistory=settingsHistory.slice(0,historyAt+1);settingsHistory.push(o);if(settingsHistory.length>40)settingsHistory.shift();historyAt=settingsHistory.length-1;}
function applyEdit(index){if(index<0||index>=settingsHistory.length)return;historyAt=index;const o=settingsHistory[index];for(const [k,v] of Object.entries(o)){const node=$(k);if(node){if(node.type==='checkbox')node.checked=v;else node.value=v;}}
 for(const [name,target] of [['angle',null],['brightness','bVal'],['contrast','cVal'],['sharpness','sVal']]){if(name==='angle')$('angle').nextElementSibling.textContent=$('angle').value+'°';else $(target).textContent=$(name).value;}
 toggleCustom();$('stampLayout').hidden=$('preset').value!=='stamp';$('passportAutoLine').hidden=$('preset').value!=='passport';invalidatePreview();msg('সেটিংস ফিরিয়ে আনা হয়েছে। নতুন PDF প্রিভিউ তৈরি করুন।');}
function undoEdit(){applyEdit(historyAt-1)}function redoEdit(){applyEdit(historyAt+1)}
for(const id of historyIds){const control=$(id);if(control)control.addEventListener('change',()=>{invalidatePreview();saveEdit()})}
saveEdit();
function toggleDark(){document.body.classList.toggle('dark');try{localStorage.setItem('porosh_pc_dark',document.body.classList.contains('dark')?'1':'0')}catch(e){}}
try{if(localStorage.getItem('porosh_pc_dark')==='1')document.body.classList.add('dark')}catch(e){}
