'use strict';
const el=id=>document.getElementById(id);
let mode='document', source=null, pdfId=null, scanned=null, nid={front:null,back:null}, list=[], photoBatch=[], documentFiles=[], previewRotation=0;
let scanSource=null, scanRect=[0,0,1,1], scannerReady=false;
const scanItems={camera:[],scanner:[]}; const scanSelected={camera:-1,scanner:-1};
function status(text,error=false){el('status').textContent=text;el('status').classList.toggle('error',error)}
const sectionIds=['regularFiles','cameraFiles','nidFiles','pdfFiles','scannerFiles'];
const titles={document:'ডকুমেন্ট নির্বাচন করুন',photo:'পাসপোর্ট ছবির ফাইল দিন',camera:'মোবাইল ক্যামেরা স্ক্যান',nid:'NID সামনে ও পেছন',pdf:'PDF ফাইল নির্বাচন করুন',scanner:'দোকানের স্ক্যানার চালু করুন'};
function setMode(selected){if(!titles[selected])selected='document';mode=selected;pdfId=null;el('resultPane').hidden=true;document.querySelectorAll('#services button').forEach(b=>b.classList.toggle('active',b.dataset.mode===mode));sectionIds.forEach(id=>el(id).hidden=id!==({document:'regularFiles',photo:'regularFiles',camera:'cameraFiles',nid:'nidFiles',pdf:'pdfFiles',scanner:'scannerFiles'}[mode]));el('titleWork').textContent=titles[mode];el('photoSettings').hidden=mode!=='photo';el('customerAiNote').hidden=mode!=='photo';el('photoBatch').hidden=mode!=='photo';el('documentSettings').hidden=!['document','photo'].includes(mode);scanSource=scanItems[mode]?.[scanSelected[mode]]||null;scanRect=scanSource?.rect?.slice()||[0,0,1,1];el('scanEditor').hidden=!scanSource;if(scanSource){el('scanCropImage').src=scanSource.preview||'/api/media/'+scanSource.token;renderScanItems();drawCrop();}el('scanAddMore').hidden=mode!=='scanner';el('create').textContent=mode==='scanner'&&!scanItems.scanner.length?'▣  স্ক্যান শুরু করুন  ➜':'◈  প্রিন্টের প্রিভিউ তৈরি করুন  ➜';status('ফাইল বা স্ক্যানের অপশন নির্বাচন করুন।')}
async function post(url,data){const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});const json=await response.json();if(!response.ok)throw Error(json.error||'অনুরোধ ব্যর্থ হয়েছে');return json}
async function upload(file){if(!file)throw Error('ফাইল নির্বাচন করুন');if(file.size>25*1024*1024)throw Error('২৫ MB-এর বেশি ফাইল গ্রহণ করা হয় না');const fd=new FormData();fd.append('file',file);const response=await fetch('/api/upload',{method:'POST',body:fd});const json=await response.json();if(!response.ok)throw Error(json.error||'আপলোড ব্যর্থ');return json}
async function uploading(file){try{status('ফাইল আপলোড হচ্ছে...');source=await upload(file);photoBatch=[];el('batchName').textContent='১–১২টি ছবি; প্রতিটির কপি সেট করে একই A4 PDF-এ সাজান';el('fileName').textContent='✓ '+source.name;status('ফাইল আপলোড হয়েছে। প্রিভিউ তৈরি করুন।')}catch(e){status(e.message,true)}}
el('file').addEventListener('change',async e=>{try{const files=[...e.target.files];if(!files.length)return;if(files.length>20)throw Error('একসঙ্গে সর্বোচ্চ ২০টি ফাইল');documentFiles=[];for(let i=0;i<files.length;i++){status(`${i+1}/${files.length} ফাইল আপলোড হচ্ছে...`);documentFiles.push(await upload(files[i]));}source=documentFiles[0];renderDocumentFiles();el('fileName').textContent=`✓ ${documentFiles.length}টি ফাইল আপলোড হয়েছে`;status('ফাইলগুলো প্রস্তুত। প্রতিটি ফাইলের Preview ও পৃষ্ঠা নির্বাচন করতে পারবেন।');}catch(x){status(x.message,true)}e.target.value='';});
function renderDocumentFiles(){const box=el('documentList');box.replaceChildren();documentFiles.forEach((f,i)=>{const row=document.createElement('div');row.className='fileItem';const meta=document.createElement('div');meta.className='meta';meta.textContent=`${i+1}. ${f.name} · ${f.kind==='image'?'ছবি':'ডকুমেন্ট'}`;const actions=document.createElement('div');const view=document.createElement('button');view.type='button';view.textContent='Preview';view.onclick=()=>{source=f;const pane=el('resultPane');pane.hidden=false;el('previewInfo').textContent=f.kind==='image'?'আপলোড করা ছবির Preview':'এই ফাইলটি PDF-এ রূপান্তর করে পূর্ণ Preview দেখুন';if(f.kind==='image'){el('pdfThumb').src=f.preview}else{el('pdfThumb').removeAttribute('src');el('pdfThumb').alt='PDF তৈরি করার পর পূর্ণ Preview দেখা যাবে';}pane.scrollIntoView({behavior:'smooth'});};const del=document.createElement('button');del.type='button';del.textContent='বাদ দিন';del.onclick=()=>{documentFiles.splice(i,1);source=documentFiles[0]||null;renderDocumentFiles()};actions.append(view,del);row.append(meta,actions);box.append(row)});}

el('cameraFile').addEventListener('change',async e=>{try{const fs=[...e.target.files];if(scanItems.camera.length+fs.length>12)throw Error('এক সেশনে সর্বোচ্চ ১২টি স্ক্যান');for(const [i,file] of fs.entries()){status(`${i+1}/${fs.length} ছবি আপলোড হচ্ছে...`);const uploaded=await upload(file);setScanSource(uploaded,'camera');}status(`${scanItems.camera.length}টি স্ক্যান প্রস্তুত। প্রতিটি ফাইল আলাদাভাবে ক্রপ করুন।`)}catch(x){status(x.message,true)}finally{e.target.value=''}});
for(const side of ['Front','Back'])el('nid'+side).addEventListener('change',async e=>{try{status('NID-এর '+side+' ছবি আপলোড হচ্ছে...');nid[side.toLowerCase()]=await upload(e.target.files[0]);el('nid'+side+'Name').textContent='✓ '+nid[side.toLowerCase()].name;status('ছবি সেভ হয়েছে। দুপাশ থাকলে PDF বানান।')}catch(x){status(x.message,true)}});
el('batchInput').addEventListener('change',async e=>{try{const fs=[...e.target.files];if(fs.length>12)throw Error('Batch-এ সর্বোচ্চ ১২টি ছবি');photoBatch=[];for(let i=0;i<fs.length;i++){status(`${i+1}/${fs.length} ছবি আপলোড হচ্ছে...`);photoBatch.push(await upload(fs[i]))}el('batchName').textContent='✓ '+photoBatch.length+'টি ছবি প্রস্তুত';status('Batch layout তৈরি করতে প্রিভিউ চাপুন।')}catch(x){status(x.message,true)}});
el('pdfInput').addEventListener('change',async e=>{try{list=[];const files=[...e.target.files];if(files.length>10)throw Error('একসাথে সর্বোচ্চ ১০টি PDF');for(let i=0;i<files.length;i++){status(`${i+1}/${files.length} PDF আপলোড হচ্ছে...`);list.push(await upload(files[i]))}el('pdfFilesName').textContent='✓ '+list.map((f,i)=>`${i+1}. ${f.name}`).join(' → ');pdfId=null;el('resultPane').hidden=true;status('PDF আপলোড হয়েছে। অপশন বেছে প্রিভিউ তৈরি করুন।')}catch(x){status(x.message,true)}});
async function scanners(){try{const response=await fetch('/api/scanners');const json=await response.json();let dev=el('scannerDevice');dev.replaceChildren();if(!json.devices.length){dev.add(new Option('WIA স্ক্যানার পাওয়া যায়নি',''));status('স্ক্যানার WIA-তে পাওয়া যায়নি। ফোনের ক্যামেরা ব্যবহার করুন।',true)}else for(const device of json.devices)dev.add(new Option(device.name,device.index))}catch(e){status('স্ক্যানারের তথ্য পাওয়া যায়নি',true)}}
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
async function doScanner(){status('স্ক্যানারের কিউতে অনুরোধ পাঠাচ্ছি...');if(!el('scannerDevice').value)throw Error('Windows WIA-তে স্ক্যানার খুঁজে পাওয়া যায়নি');const started=await post('/api/scanners/scan',{device:Number(el('scannerDevice').value),dpi:Number(el('scanDpi').value)});for(let i=0;i<90;i++){await sleep(1250);let r=await fetch('/api/scanners/job/'+started.id);if(!r.ok)throw Error('স্ক্যানের অবস্থা পাওয়া যায়নি');let j=await r.json();status(j.status==='scanning'?'দোকানের স্ক্যানারে স্ক্যান চলছে...':'স্ক্যান কিউতে অপেক্ষা চলছে...');if(j.status==='ready'){source={token:j.token,kind:'image',name:'Scanner-'+(scanItems.scanner.length+1)+'.jpg',preview:j.preview};setScanSource(source,'scanner');scannerReady=true;el('create').textContent='◈ ক্রপ ঠিক করে PDF প্রিভিউ তৈরি করুন ➜';status(`${scanItems.scanner.length}টি স্ক্যান রাখা হয়েছে। প্রতিটি আলাদাভাবে ক্রপ করা যাবে; চাইলে আরেকটি স্ক্যান যোগ করুন।`);return null}if(j.status==='error')throw Error(j.detail||'স্ক্যান ব্যর্থ')}throw Error('স্ক্যান সময়সীমা পেরিয়ে গেছে; কিউ পরীক্ষা করুন')}
async function prepare(){el('create').disabled=true;status('প্রক্রিয়াকরণ চলছে...');try{let out;
if(mode==='document'){if(!documentFiles.length)throw Error('এক বা একাধিক ফাইল বেছে নিন');const prepared=[];for(let i=0;i<documentFiles.length;i++){const f=documentFiles[i];status(`${i+1}/${documentFiles.length} ফাইলের PDF তৈরি হচ্ছে...`);const d={token:f.token,mode:'document',paper:el('paper').value,paper_orientation:el('docOrientation').value,fit:el('fit').value,pages:el('pageRange').value||'all',angle:Number(el('rotateImage').value)};const one=await post('/api/prepare',d);prepared.push(one);}out=prepared.length===1?prepared[0]:await post('/api/combine-prepared',{exports:prepared.map(x=>x.export)});}

else if(mode==='photo'&&photoBatch.length){out=await post('/api/batch-photo',{tokens:photoBatch.map(f=>f.token),preset:el('photoPreset').value,copies_each:Number(el('batchCopies').value)});}
else if(mode==='photo'){if(!source||source.kind!=='image')throw Error('ছবি বেছে নিন');let token=source.token;if(Number(el('soften').value)>0){status('হালকা ফেস সফটেনিং হচ্ছে...');let softened=await post('/api/retouch',{token,strength:Number(el('soften').value)});token=softened.token}out=await post('/api/prepare',{token,mode:'photo',preset:el('photoPreset').value,count:Number(el('photoCount').value),paper:el('paper').value,paper_orientation:el('photoOrientation').value,background:el('photoBg').value,background_color:el('bgcolor').value,photo_dpi:Number(el('photoDpi').value),enhance:true});}
else if(mode==='camera'){if(!scanItems.camera.length)throw Error('ক্যামেরার ছবি তুলুন');out=await createScanPdf();}
else if(mode==='nid'){if(!nid.front||!nid.back)throw Error('NID-এর সামনে ও পেছনের ছবি দুটো দিন');out=await post('/api/nid',{front:nid.front.token,back:nid.back.token,auto_crop:el('nidAuto').checked,enhance:true});}
else if(mode==='pdf'){
 const action=el('pdfAction').value;
 if(action==='merge' && (list.length<2 || list.length>10))throw Error('Merge করতে ২–১০টি PDF দিন');
 if(action!=='merge' && list.length!==1)throw Error('এই কাজের জন্য একটি PDF দিন');
 out=await post('/api/pdf-tools',{tokens:list.map(f=>f.token),action,pages:el('pdfPages').value.trim()||'all',rotation:Number(el('pdfRotation').value)});
}
else if(mode==='scanner')out=scanItems.scanner.length?await createScanPdf():await doScanner();
if(!out)return;
pdfId=out.export;previewRotation=0;el('pdfThumb').style.transform='rotate(0deg)';el('pdfThumb').src='/api/pdf-thumb/'+pdfId+'?v='+Date.now();el('openPdf').href='/api/pdf/'+pdfId;el('previewInfo').textContent=`${out.pages||1} পৃষ্ঠা তৈরি হয়েছে। ${out.note||'ছবির আসল লেখা পরিবর্তন করা হয়নি।'}`;el('resultPane').hidden=false;status('প্রিভিউ তৈরি হয়েছে! দেখে নিশ্চিত হয়ে প্রিন্ট করুন।');el('resultPane').scrollIntoView({behavior:'smooth',block:'start'});
}catch(e){status(e.message,true)}finally{el('create').disabled=false}}
el('create').addEventListener('click',prepare);
el('rotatePreview').addEventListener('click',()=>{previewRotation=(previewRotation+90)%360;el('pdfThumb').style.transform=`rotate(${previewRotation}deg)`;});
el('openPreview').addEventListener('click',()=>{if(pdfId)window.open('/api/pdf/'+pdfId,'_blank','noopener');else if(source?.preview)window.open(source.preview,'_blank','noopener')});
el('print').addEventListener('click',async ()=>{if(!pdfId)return; if(!confirm('সঠিক প্রিন্টার, কাগজ, কপি ও প্রিভিউ পরীক্ষা করেছেন?'))return;try{el('print').disabled=true;status('প্রিন্ট কিউতে পাঠানো হচ্ছে...');let j=await post('/api/print',{export:pdfId,printer:el('printer').value,copies:Number(el('copies').value),paper:['document','photo'].includes(mode)?el('paper').value:(['camera','scanner'].includes(mode)?(el('scanPaper').value==='ID'?'custom':el('scanPaper').value):'A4'),color:el('color').value,quality:el('quality').value});location.href=j.url;}catch(e){status(e.message,true);el('print').disabled=false}});
el('theme').addEventListener('click',()=>{document.body.classList.toggle('dark');localStorage.setItem('porosh_dark',document.body.classList.contains('dark')?'1':'0')});if(localStorage.getItem('porosh_dark')==='1')document.body.classList.add('dark');
document.querySelectorAll('#services button').forEach(b=>b.addEventListener('click',()=>{setMode(b.dataset.mode);if(mode==='scanner')scanners()}));
setMode(new URLSearchParams(location.search).get('service')||'document');

// PDF tools: show only the controls relevant to the chosen operation.
function updatePdfControls(){
 const action=el('pdfAction').value;
 el('pagesWrap').hidden=!['split','rotate','reorder','delete','odd','even'].includes(action);
 el('pdfRotateWrap').hidden=action!=='rotate';
 const descriptions={merge:'একাধিক PDF ফাইল ২–১০টি নির্বাচন করুন। নির্বাচন করা ক্রমেই যোগ হবে।',
 split:'1,3,5-7 লিখলে ওই পৃষ্ঠাগুলো নিয়ে একটি নতুন PDF হবে। আলাদা ZIP নয়।',
 compress:'ছবি ছোট না করে লেখা, স্ক্যান ও পৃষ্ঠা অক্ষত রেখে PDF Optimize করা হবে।',
 rotate:'all দিলে সব পৃষ্ঠা ঘুরবে; 1,3-5 দিলে শুধু ওই পৃষ্ঠাগুলো ঘুরবে।',
 reorder:'উদাহরণ: 3,1,2 দিলে তৃতীয় পৃষ্ঠা আগে আসবে। তালিকায় না থাকা পৃষ্ঠা বাদ যাবে।',
 delete:'উদাহরণ: 2,4 দিলে ওই দুটি পৃষ্ঠা বাদ যাবে। সব পৃষ্ঠা বাদ দেওয়া যাবে না।',
 odd:'১,৩,৫… নম্বরের পৃষ্ঠাগুলো আলাদা PDF-এ রেখে আগে প্রিভিউ করুন।',
 even:'২,৪,৬… নম্বরের পৃষ্ঠাগুলো আলাদা PDF-এ রেখে আগে প্রিভিউ করুন।'};
 el('pdfHelp').textContent=descriptions[action];
}
el('pdfAction').addEventListener('change',()=>{updatePdfControls();pdfId=null;el('resultPane').hidden=true;});
el('pdfRotation').addEventListener('change',()=>{pdfId=null;el('resultPane').hidden=true;});
el('pdfPages').addEventListener('input',()=>{pdfId=null;el('resultPane').hidden=true;});
updatePdfControls();


// In-session scan collection: every uploaded/scanned file has its own persistent crop.
function renderScanItems(){
 const box=el('scanItems');box.replaceChildren();
 const arr=scanItems[mode]||[];
 arr.forEach((f,i)=>{const b=document.createElement('button');b.type='button';b.className=i===scanSelected[mode]?'active':'';
 const im=document.createElement('img');im.src=f.preview||'/api/media/'+f.token;im.alt='';
 const label=document.createElement('span');label.textContent=`${i+1}. ${f.name||'Scan'}${f.edited?' ✓':''}`;
 b.append(im,label);b.onclick=()=>selectScan(i);box.append(b);});
}
function selectScan(i){
 const arr=scanItems[mode]||[];if(i<0||i>=arr.length)return;
 scanSelected[mode]=i;scanSource=arr[i];scanRect=scanSource.rect.slice();
 el('scanEditor').hidden=false;el('scanCropImage').src=scanSource.preview||'/api/media/'+scanSource.token;
 el('scanAddMore').hidden=mode!=='scanner';renderScanItems();drawCrop();
}
function setScanSource(file, via){
 const arr=scanItems[via];if(arr.length>=12)throw Error('এক সেশনে সর্বোচ্চ ১২টি স্ক্যান নেওয়া যায়');
 const f={...file,via,rect:[0,0,1,1],edited:false};arr.push(f);
 if(mode===via)selectScan(arr.length-1);
}
function drawCrop(){
 const [x,y,w,h]=scanRect,box=el('scanCropSelection');
 Object.assign(box.style,{left:(x*100)+'%',top:(y*100)+'%',width:(w*100)+'%',height:(h*100)+'%',right:'auto',bottom:'auto'});
 el('scanCropInfo').textContent=`স্ক্যান ${scanSelected[mode]+1}/${scanItems[mode].length} · ক্রপ: ${Math.round(w*100)}% × ${Math.round(h*100)}%`;
 if(scanSource){scanSource.rect=[...scanRect];scanSource.edited=scanRect.some((v,i)=>Math.abs(v-[0,0,1,1][i])>0.001);}
 pdfId=null;el('resultPane').hidden=true;
}
const cropFrame=el('scanCropFrame');let startCrop=null;
function clampCrop(n){return Math.min(1,Math.max(0,n))}
function coordsCrop(e){const r=el('scanCropImage').getBoundingClientRect();return [clampCrop((e.clientX-r.left)/r.width),clampCrop((e.clientY-r.top)/r.height)]}
cropFrame.addEventListener('pointerdown',e=>{if(!scanSource)return;e.preventDefault();startCrop=coordsCrop(e);cropFrame.setPointerCapture(e.pointerId);scanRect=[startCrop[0],startCrop[1],.001,.001];drawCrop()});
cropFrame.addEventListener('pointermove',e=>{if(!startCrop)return;let t=coordsCrop(e);scanRect=[Math.min(startCrop[0],t[0]),Math.min(startCrop[1],t[1]),Math.max(.001,Math.abs(startCrop[0]-t[0])),Math.max(.001,Math.abs(startCrop[1]-t[1]))];drawCrop()});
function endCrop(){if(!startCrop)return;startCrop=null;if(scanRect[2]<.02||scanRect[3]<.02)scanRect=[0,0,1,1];drawCrop();renderScanItems()}
cropFrame.addEventListener('pointerup',endCrop);cropFrame.addEventListener('pointercancel',endCrop);
el('scanResetCrop').onclick=()=>{scanRect=[0,0,1,1];drawCrop();renderScanItems()};
el('scanRemove').onclick=()=>{
 const arr=scanItems[mode];if(!arr||scanSelected[mode]<0)return;
 arr.splice(scanSelected[mode],1);scanSelected[mode]=Math.min(scanSelected[mode],arr.length-1);
 if(arr.length)selectScan(scanSelected[mode]);else{scanSource=null;el('scanEditor').hidden=true;el('scanItems').replaceChildren();}
 pdfId=null;el('resultPane').hidden=true;
 if(mode==='scanner'&&!arr.length)el('create').textContent='▣ স্ক্যান শুরু করুন ➜';
 status(arr.length+'টি স্ক্যান রাখা হয়েছে।');
};
el('scanAddMore').onclick=async()=>{
 try{el('scanAddMore').disabled=true;if(scanItems.scanner.length>=12)throw Error('সর্বোচ্চ ১২টি স্ক্যান');await doScanner()}
 catch(x){status(x.message,true)}finally{el('scanAddMore').disabled=false}
};
el('scanPaper').addEventListener('change',()=>{el('scanCustom').hidden=el('scanPaper').value!=='custom';pdfId=null;el('resultPane').hidden=true;});
['scanFit','scanOrientation','scanCustomW','scanCustomH','scanColor','scanLayout','scanColumns'].forEach(id=>el(id).addEventListener('change',()=>{pdfId=null;el('resultPane').hidden=true;}));
el('scanLayout').addEventListener('change',()=>{el('scanColumns').disabled=el('scanLayout').value==='separate_pages'});
['scannerDevice','scanDpi'].forEach(id=>el(id).addEventListener('change',()=>{scannerReady=false;pdfId=null;el('resultPane').hidden=true;status('স্ক্যানারের সেটিং পরিবর্তিত হয়েছে। আগের স্ক্যানগুলো রাখা আছে; চাইলে নতুন স্ক্যান যোগ করুন।');}));
async function createScanPdf(){
 const arr=scanItems[mode];if(!arr?.length)throw Error('স্ক্যান প্রস্তুত নয়');
 const data={scans:arr.map(f=>({token:f.token,rect:f.rect})),paper:el('scanPaper').value,
  orientation:el('scanOrientation').value,custom_w:Number(el('scanCustomW').value),custom_h:Number(el('scanCustomH').value),
  fit:el('scanFit').value,mode:el('scanColor').value,layout:el('scanLayout').value,columns:Number(el('scanColumns').value)};
 status('প্রতিটি স্ক্যানের আলাদা ক্রপ মিলিয়ে PDF তৈরি হচ্ছে...');
 return await post('/api/scan-sheet',data);
}
