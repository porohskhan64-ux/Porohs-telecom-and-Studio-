from tempfile import TemporaryDirectory
from pathlib import Path
from unittest.mock import patch
from PIL import Image
import fitz
from engine import enhance_image,make_photo_layout,estimate_photo_tilt

with TemporaryDirectory() as d:
    source=Path(d)/'portrait.jpg'
    Image.new('RGB',(600,800),(85,120,160)).save(source)
    # An ambiguous photo is NOT rotated based on guesses.
    angle,status=estimate_photo_tilt(Image.new('RGB',(200,200),'white'))
    assert angle==0.0 and status!='detected',(angle,status)
    with patch('engine.estimate_photo_tilt',return_value=(5.0,'detected')):
        im=enhance_image(source,auto=True,photo_straighten=True)
        assert im.info['photo_alignment_status']=='detected'
        assert im.info['photo_angle_deg']==5.0
        assert im.width>600 and im.height>800
        out=Path(d)/'portrait.pdf'
        meta=make_photo_layout(source,out,auto=True,photo_straighten=True)
        assert meta['photo_alignment_status']=='detected',meta
        with fitz.open(out) as doc:assert len(doc)==1
print('PASS: Auto Photo conservative detection + fixed-angle rotation + PDF')
