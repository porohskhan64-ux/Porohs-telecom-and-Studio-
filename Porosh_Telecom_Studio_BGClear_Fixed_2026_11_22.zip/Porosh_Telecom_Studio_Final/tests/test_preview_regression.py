"""Regression tests: actual upload preview bytes (without Flask), UI wiring, portrait paper packing."""
import ast
import io
from pathlib import Path
from tempfile import TemporaryDirectory
from PIL import Image, ImageOps
import fitz
from engine import make_photo_layout

ROOT=Path(__file__).resolve().parents[1]

def run():
    source=(ROOT/'app.py').read_text(encoding='utf8')
    tree=ast.parse(source)
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='media')
    node.decorator_list=[]
    # Execute the actual media-route function body with a lightweight test send_file.
    # This catches the original UnboundLocalError caused by reimporting Image inside it.
    with TemporaryDirectory() as t:
        path=Path(t)/'photo.jpg'
        Image.new('RGB',(600,800),'#8bbbd4').save(path)
        sent={}
        def send_file(stream,**kwargs):
            sent.update(kwargs);return stream.read()
        env={'target_by_token':lambda token:path,'IMAGE_EXT':{'.jpg'},'Image':Image,
             'ImageOps':ImageOps,'io':io,'send_file':send_file,'abort':lambda code:None}
        exec(compile(ast.fix_missing_locations(ast.Module(body=[node],type_ignores=[])),str(ROOT/'app.py'),'exec'),env)
        jpeg=env['media']('token')
        assert jpeg.startswith(b'\xff\xd8') and sent['mimetype']=='image/jpeg',sent
        with Image.open(io.BytesIO(jpeg)) as preview:
            assert preview.size==(750,1000) or max(preview.size)<=1000,preview.size
        assert sent['max_age']==0, sent
        out=Path(t)/'portrait_sheet.pdf'
        meta=make_photo_layout(path,out,preset='passport',count=4,photo_dpi=300,
                               paper='A4',paper_orientation='portrait',passport_row_layout=True)
        assert meta['paper_mm']==[210,297] and meta['photo_pixels']==[450,570]
        with fitz.open(out) as doc:
            assert doc[0].rect.height>doc[0].rect.width
            img=doc[0].get_images()[0][0]
            rects=doc[0].get_image_rects(img)
            assert len(rects)==4 and rects[0].x0<rects[1].x0<rects[2].x0,rects
            assert all(r.height>r.width for r in rects)
        out2=Path(t)/'one_column.pdf'
        meta2=make_photo_layout(path,out2,preset='passport',count=4,
                                paper='A4',paper_orientation='portrait',passport_row_layout=False)
        with fitz.open(out2) as doc:
            rects=doc[0].get_image_rects(doc[0].get_images()[0][0])
            assert len(rects)==4 and all(abs(r.x0-rects[0].x0)<1 for r in rects)

    js=(ROOT/'static/studio.js').read_text(encoding='utf8')
    html=(ROOT/'templates/studio.html').read_text(encoding='utf8')
    assert "if(j.kind==='image'&&mode==='photo')void showStraightCompare()" in js
    assert 'beforeStraight' in js and 'afterStraight' in js
    assert "o.paper_orientation='landscape'" not in js
    assert 'আগে-পরে প্রিভিউ আবার দেখুন' in html
    assert html.index('id="straightCompare"')<html.index('id="photoOptions"')
    assert 'পাসপোর্ট ছবি পাশাপাশি সাজান' in html
    print('PASS: real media preview bytes, automatic compare UI, portrait 4 photos in horizontal rows, manual column')

if __name__=='__main__':run()
