from io import BytesIO
from unittest.mock import patch
from urllib.error import HTTPError
from PIL import Image
from online_ai import remove_background, AIServiceError, API_URL
from engine import enhance_image, make_photo_layout
from tempfile import TemporaryDirectory
from pathlib import Path
import fitz

class Reply:
    def __init__(self, body):
        self.body=body
        self.headers={'Content-Type':'image/png'}
    def __enter__(self):return self
    def __exit__(self,*a):pass
    def read(self,n):return self.body[:n]

def test_bgclear_preview_and_layout():
    im=Image.new('RGB',(500,500),'white')
    output=Image.new('RGBA',(500,500),(255,0,0,255))
    for x in range(250):
        for y in range(500):output.putpixel((x,y),(0,0,0,0))
    b=BytesIO();output.save(b,format='PNG')
    def fake(req,timeout):
        assert req.full_url==API_URL
        assert req.headers['Authorization']=='Bearer test_bgclear_key'
        assert b'name="size"\r\n\r\npreview' in req.data
        assert b'name="store"\r\n\r\nfalse' in req.data
        assert b'name="crop"\r\n\r\nfalse' in req.data
        assert b'name="image_file"' in req.data
        assert b'name="format"\r\n\r\npng' in req.data
        assert b'name="type"' not in req.data
        assert b'full' not in req.data
        return Reply(b.getvalue())
    with patch('online_ai.urlopen',side_effect=fake):
        cutout=remove_background(im,'test_bgclear_key')
        assert cutout.size==im.size and cutout.getpixel((0,0))[3]==0
        with TemporaryDirectory() as t:
            src=Path(t)/'original.png'; im.save(src)
            result=make_photo_layout(src,Path(t)/'print.pdf',preset='passport',count=6,
                                     background='white',ai_key='test_bgclear_key',
                                     photo_straighten=False,angle=0)
            assert result['background_method']=='bgclear_online_ai_preview'
            assert result['photo_dpi']==300
            assert result['photo_angle_deg']==0
            with fitz.open(Path(t)/'print.pdf') as pdf:
                assert len(pdf)==1 and len(pdf[0].get_images())>=1
    with patch('online_ai.urlopen',side_effect=HTTPError(API_URL,401,'denied',None,None)):
        try:remove_background(im,'test_bgclear_key')
        except AIServiceError as e:assert 'test_bgclear_key' not in str(e)
        else:raise AssertionError('Expected credential failure')


def test_bgclear_reports_specific_invalid_image_format():
    im=Image.new('RGB',(20,20),'white')
    body=b'{"error":{"code":"unsupported_format","message":"Invalid format"}}'
    from io import BytesIO
    from urllib.error import HTTPError
    err=HTTPError(API_URL,400,'Bad Request',{},BytesIO(body))
    with patch('online_ai.urlopen',side_effect=err):
        try:
            remove_background(im,'test_bgclear_key')
        except AIServiceError as exc:
            assert 'ফাইল ফরম্যাট' in str(exc)
            assert 'Invalid format' not in str(exc)
        else:
            raise AssertionError('Expected unsupported format error')


def test_original_does_not_call_api():
    with TemporaryDirectory() as t:
        src=Path(t)/'source.png';Image.new('RGB',(500,500),'red').save(src)
        with patch('engine.remove_background') as call:
            result=make_photo_layout(src,Path(t)/'print.pdf',preset='passport',count=4,background='original',photo_straighten=False)
            assert result['background_method']=='original' and result['photo_angle_deg']==0
            call.assert_not_called()
