"""End-to-end PDF geometry and conversion preset regressions (no physical printer needed)."""
from pathlib import Path
from tempfile import TemporaryDirectory
from PIL import Image
import fitz
from engine import make_photo_layout, photo_size


def run():
    assert photo_size('passport', 35, 45) == (38.1, 48.26)
    assert photo_size('stamp', 38.1, 48.26) == (25.0, 30.0)
    with TemporaryDirectory() as temp:
        home = Path(temp)
        photo = home/'photo.jpg'
        Image.new('RGB', (650, 800), '#bcd9e8').save(photo)
        passport = home/'passport.pdf'
        pmeta = make_photo_layout(photo, passport, preset='passport', photo_dpi=300, paper='A4',
                                  paper_orientation='landscape', count=4)
        assert pmeta['photo_mm'] == [38.1, 48.26], pmeta
        assert pmeta['photo_pixels'] == [450, 570], pmeta
        assert pmeta['photo_dpi'] == 300
        assert pmeta['paper_mm'] == [297, 210]
        with fitz.open(passport) as pdf:
            assert len(pdf) == 1
            assert pdf[0].rect.width > pdf[0].rect.height
            assert abs(pdf[0].rect.width - 297 * 72/25.4) < .02
            assert len(pdf[0].get_images(full=True)) == 1
            imgmeta = pdf.extract_image(pdf[0].get_images()[0][0])
            assert imgmeta['width'] == 450 and imgmeta['height'] == 570, imgmeta
        stamp = home/'stamp.pdf'
        smeta = make_photo_layout(photo, stamp, preset='stamp', paper='A4',
                                  paper_orientation='portrait', count=7,
                                  stamp_columns=3, stamp_gap=3.5, stamp_margin=7)
        assert smeta['photo_mm'] == [25, 30]
        assert smeta['photo_dpi'] == 150
        assert smeta['photo_pixels'] == [148, 177]
        assert smeta['per_page'] == 24, smeta
        with fitz.open(stamp) as pdf:
            assert len(pdf) == 1
            assert pdf[0].rect.height > pdf[0].rect.width
            assert len(pdf[0].get_images(full=True)) == 1
            assert len(pdf[0].get_image_rects(pdf[0].get_images()[0][0])) == 7
            image=pdf.extract_image(pdf[0].get_images()[0][0])
            assert image['width']==148 and image['height']==177
        try:
            make_photo_layout(photo, home/'too_many.pdf', preset='stamp', paper='A6',
                              stamp_columns=10)
        except ValueError as exc:
            assert 'কলাম' in str(exc)
        else:
            raise AssertionError('Too many stamp columns must be rejected')
        # Existing custom and explicit non-auto portrait photo modes remain possible.
        custom=make_photo_layout(photo,home/'custom.pdf',preset='custom',photo_w=40,photo_h=50,photo_dpi=300,
                                 paper='A5',paper_orientation='portrait')
        assert custom['photo_mm']==[40,50] and custom['paper_mm']==[148,210]
    print('PASS: Passport 1.5x1.9in 300 DPI landscape; stamp conversion 25x30mm 150 DPI manual columns/spacing; custom unchanged')


if __name__=='__main__':run()
