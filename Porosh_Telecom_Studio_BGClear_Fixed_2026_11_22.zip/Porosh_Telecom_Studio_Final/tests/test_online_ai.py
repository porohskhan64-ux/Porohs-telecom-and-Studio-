"""Mocked AI transport and Flask security/geometry integration. No credits used."""
from io import BytesIO
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
import os, re, zipfile

from PIL import Image
from urllib.error import HTTPError, URLError
import fitz
import app as server
from engine import enhance_image, make_photo_layout
from online_ai import AIServiceError, remove_background, API_URL

class Reply:
    def __init__(self,data):self.data=data;self.headers={"Content-Type":"image/png"}
    def __enter__(self):return self
    def __exit__(self,*args):return None
    def read(self,length):return self.data[:length]


def png_response():
    im=Image.new('RGBA',(100,150),(255,0,0,255))
    for x in range(50):
        for y in range(150):im.putpixel((x,y),(255,0,0,0))
    out=BytesIO();im.save(out,format='PNG');return out.getvalue()


def run():
    sample=Image.new('RGB',(100,150),'#aaaaaa')
    called={}
    def success(request, timeout):
        called['url']=request.full_url;called['data']=request.data
        called['headers']=request.headers;called['timeout']=timeout
        return Reply(png_response())
    with patch('online_ai.urlopen',side_effect=success):
        result=remove_background(sample,'fake-key-for-test')
    assert called['url']==API_URL and called['timeout']==45
    assert b'name="image_file"' in called['data'] and b'name="crop"' in called['data']
    assert b'\r\nfalse\r\n' in called['data']
    assert called['headers']['Authorization']=='Bearer fake-key-for-test'
    assert result.mode=='RGBA' and result.size==sample.size
    assert result.getpixel((10,10))[3]==0
    with patch('online_ai.urlopen',side_effect=HTTPError(API_URL,401,'',None,None)):
        try:remove_background(sample,'key-without-access')
        except AIServiceError as e:assert 'key' in str(e) and 'key-without-access' not in str(e)
        else:raise AssertionError('401 must not succeed')
    with patch('online_ai.urlopen',side_effect=URLError('failure')):
        try:remove_background(sample,'key-without-internet')
        except AIServiceError as e:assert 'ইন্টারনেট' in str(e)
        else:raise AssertionError('network error must not be silently downgraded')
    with TemporaryDirectory() as d:
        src=Path(d)/'photo.jpg';sample.save(src)
        cutout=Image.open(BytesIO(png_response())).convert('RGBA')
        with patch('engine.remove_background',return_value=cutout) as segment:
            im=enhance_image(src,background='sky',background_provider='bgclear',ai_key='test')
            assert segment.call_count==1
            assert im.info['background_method']=='bgclear_online_ai_preview'
            assert im.getpixel((0,0))==(124,202,248)
            assert im.getpixel((90,50))==(255,0,0)
            meta=make_photo_layout(src,Path(d)/'passport.pdf',preset='passport',background='white',background_provider='auto',ai_key='test',count=2)
            assert meta['background_method']=='bgclear_online_ai_preview'
            with fitz.open(Path(d)/'passport.pdf') as pdf:
                assert pdf.page_count==1
        with patch('engine.remove_background') as segment:
            orig=enhance_image(src,background='original',background_provider='bgclear',ai_key='test')
            assert segment.call_count==0 and orig.info['background_method']=='original'
        with patch.object(server,'AI_KEY_FILE',Path(d)/'keyfile'), patch.dict(os.environ,{'BGCLEAR_API_KEY':''}), patch('app.is_admin_authenticated',return_value=True), patch('app.is_admin_local',return_value=True):
            server.app.config['TESTING']=True
            client=server.app.test_client()
            r=client.get('/admin');assert r.status_code==200
            token=re.search(rb'name="csrf" value="([a-f0-9]{32})"',r.data).group(1).decode()
            r=client.post('/admin/ai-key',data={'csrf':token,'action':'save','bgclear_api_key':'example_TEST_key_123456'})
            assert r.status_code==302, r.data
            assert server.get_ai_key()=='example_TEST_key_123456'
            r=client.get('/admin');assert r.status_code==200 and b'example_TEST_key_123456' not in r.data
            r=client.post('/admin/backup',data={'csrf':token})
            assert r.status_code==200
            with zipfile.ZipFile(BytesIO(r.data)) as z:
                assert 'bgclear_api.key' not in z.namelist()
                assert b'example_TEST_key_123456' not in r.data
            # Wrong CSRF cannot replace credential
            r=client.post('/admin/ai-key',data={'csrf':'x','bgclear_api_key':'bad-but-valid-key'})
            assert r.status_code==403
            assert server.get_ai_key()=='example_TEST_key_123456'
            r=client.post('/admin/ai-key',data={'csrf':token,'action':'remove'})
            assert r.status_code==302 and not (Path(d)/'keyfile').exists()
        # Public LAN user cannot run paid API, even with valid customer token.
        with patch('app.get_ai_key',return_value='configured-valid-key'), patch('app.is_admin_authenticated',return_value=False):
            with server.app.test_request_context('/api/prepare',method='POST',json={}):
                server.g.sid='0123456789abcdef0123456789abcdef'
                try:server.process_file(src,{'mode':'photo','background':'white','background_provider':'bgclear'},Path(d)/'blocked.pdf')
                except ValueError as exc:assert 'অ্যাডমিন' in str(exc)
                else:raise AssertionError('non-admin cannot call online AI')
    print('PASS: Online AI request/multipart/alpha/errors; engine compositing; admin secret/CSRF/backup; customer no API billing')

if __name__=='__main__':run()
