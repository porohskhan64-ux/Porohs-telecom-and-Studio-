"""Invoke `python tests/test_scan_batch.py` from project root; no network required."""
from pathlib import Path
from tempfile import TemporaryDirectory
from PIL import Image, ImageDraw
import fitz
from extra_tools import scan_batch_to_pdf, pdf_action

def run():
    with TemporaryDirectory() as dir:
        d=Path(dir)
        # Both scans have distinct content. Selecting opposite sides must
        # remain independent after composing multiple scans on one page.
        for filename in ('scan1.png','scan2.png'):
            im=Image.new('RGB',(600,600),'white')
            draw=ImageDraw.Draw(im)
            draw.rectangle((0,0,299,599),fill=(235,35,25))
            draw.rectangle((300,0,599,599),fill=(25,60,240))
            im.save(d/filename)
        items=[(d/'scan1.png',[0,0,.48,1]),(d/'scan2.png',[.52,0,.48,1])]
        out=d/'combined.pdf'
        meta=scan_batch_to_pdf(items,out,paper='A4',columns=2)
        assert meta['pages']==1 and meta['scans']==2 and meta['columns']==2
        with fitz.open(out) as doc:
            assert doc.page_count==1
            pg=doc[0];assert abs(pg.rect.width - 210*72/25.4)<.02
            pix=pg.get_pixmap(alpha=False, matrix=fitz.Matrix(1,1))
            pixels=[pix.pixel(x,y) for x in range(20,pix.width-20,8) for y in range(20,pix.height-20,12)]
            red=sum(c[0]>180 and c[1]<100 and c[2]<100 for c in pixels)
            blue=sum(c[2]>175 and c[0]<100 and c[1]<135 for c in pixels)
            assert red>30 and blue>30, f'Independent crops missing: red={red},blue={blue}'
        multi=d/'separate.pdf'
        meta=scan_batch_to_pdf(items,multi,paper='A5',layout='separate_pages')
        assert meta['pages']==2
        with fitz.open(multi) as pdf:
            assert pdf.page_count==2
            assert all(abs(pg.rect.width-148*72/25.4)<.02 for pg in pdf)
        # Alternate crop of same source also supported without changing original.
        meta=scan_batch_to_pdf([(d/'scan1.png',[0,0,.48,1]),(d/'scan1.png',[.52,0,.48,1])],d/'same-source.pdf')
        assert meta['scans']==2
        assert Image.open(d/'scan1.png').size==(600,600)
        try:scan_batch_to_pdf([(d/'scan1.png',[.95,.1,.5,.8])],d/'bad.pdf')
        except ValueError:pass
        else:raise AssertionError('Out of range crop accepted')
        try:scan_batch_to_pdf(items*7,d/'too-many.pdf')
        except ValueError:pass
        else:raise AssertionError('More than 12 scans accepted')
        original=d/'fifteen.pdf'
        with fitz.open() as pdf:
            for i in range(1,16):pdf.new_page().insert_text((80,80),f'PAGE_{i}')
            pdf.save(original)
        odd=pdf_action([original],d/'odd.pdf','odd',pages='all')
        even=pdf_action([original],d/'even.pdf','even',pages='all')
        assert odd['pages']==8 and even['pages']==7
        with fitz.open(d/'odd.pdf') as a,fitz.open(d/'even.pdf') as b:
            assert 'PAGE_1' in a[0].get_text() and 'PAGE_15' in a[-1].get_text()
            assert 'PAGE_2' in b[0].get_text() and 'PAGE_14' in b[-1].get_text()
    print('PASS scan batch: independent crops, same-page/separate-page layout, 2 crop selections of 1 source, 15-page odd/even, limits')

if __name__=='__main__':run()
