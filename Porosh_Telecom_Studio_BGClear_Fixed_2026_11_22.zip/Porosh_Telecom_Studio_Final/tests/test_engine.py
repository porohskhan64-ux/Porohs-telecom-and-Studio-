from pathlib import Path
from PIL import Image
from tempfile import TemporaryDirectory
import fitz
from engine import make_photo_layout,make_document_image_pdf,make_selected_pdf,parse_pages

def run():
    with TemporaryDirectory() as t:
        root=Path(t)
        src=root/'face.jpg'; Image.new('RGB',(500,700),'#88bbee').save(src)
        for paper,orientation,count in [('A4','portrait',4),('A5','landscape',8),('custom','landscape',4)]:
            out=root/(paper+orientation+'.pdf')
            options={'paper_w':120,'paper_h':85} if paper=='custom' else {}
            result=make_photo_layout(src,out,count=count,paper=paper,paper_orientation=orientation,**options)
            with fitz.open(out) as pdf:
                assert len(pdf)==result['pages']
                assert pdf[0].rect.width>0
                assert result['pages']>=1
        doc=root/'doc.pdf';fitz.open().save(doc) if False else None
        with fitz.open() as p:
            for i in range(5):p.new_page()
            p.save(doc)
        selected=root/'selected.pdf';res=make_selected_pdf(doc,selected,pages='1,3,5')
        with fitz.open(selected) as p:assert len(p)==3
        assert parse_pages('2-4',5)==[1,2,3]
        imageout=root/'scan.pdf'
        make_document_image_pdf(src,imageout,paper='A5',auto=True)
        with fitz.open(imageout) as p:assert len(p)==1
    print('PASS: photo A4/A5/custom, selected PDF pages, document image PDF')

if __name__=='__main__':run()
