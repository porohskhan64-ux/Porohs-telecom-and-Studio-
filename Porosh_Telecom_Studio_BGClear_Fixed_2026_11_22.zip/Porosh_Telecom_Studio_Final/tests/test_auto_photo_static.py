from pathlib import Path
b=Path(__file__).resolve().parents[1]
assert 'id="enhance" checked' in (b/'templates/studio.html').read_text('utf8')
assert 'id="photo_straighten" checked' in (b/'templates/studio.html').read_text('utf8')
assert 'photo_straighten' in (b/'app.py').read_text('utf8')
assert "o.photo_straighten=$('photo_straighten').checked" in (b/'static/studio.js').read_text('utf8')
assert 'opencv-python-headless' in (b/'requirements.txt').read_text('utf8')
print('PASS: Auto Photo controls default ON and wired to server')
