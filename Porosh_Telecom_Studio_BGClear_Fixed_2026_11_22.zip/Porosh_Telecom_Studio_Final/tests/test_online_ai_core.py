"""Offline mocked Photoroom and PDF compositing tests; does not require Flask."""
from io import BytesIO
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from urllib.error import HTTPError, URLError

from PIL import Image
import fitz
from engine import enhance_image, make_photo_layout
from online_ai import AIServiceError, API_URL, remove_background

class MockReply:
    def __init__(self, data): self.data=data;self.headers={"Content-Type":"image/png"}
    def __enter__(self): return self
    def __exit__(self, *args): pass
    def read(self, n): return self.data[:n]


def test_png():
    image=Image.new('RGBA',(100,150),(255,0,0,255))
    for x in range(50):
        for y in range(150):image.putpixel((x,y),(255,0,0,0))
    result=BytesIO();image.save(result,format='PNG')
    return result.getvalue()


def run():
    image=Image.new('RGB',(100,150),'#aabbcc')
    req_data={}
    def send(req,timeout):
        req_data.update(url=req.full_url,body=req.data,headers=req.headers,timeout=timeout)
        return MockReply(test_png())
    with patch('online_ai.urlopen', side_effect=send):
        cutout=remove_background(image,'test_photoroom_key')
    assert req_data['url']==API_URL and req_data['timeout']==45
    assert b'name="image_file"' in req_data['body']
    assert b'name="size"' in req_data['body'] and b'\r\npreview\r\n' in req_data['body']
    assert b'name="crop"' in req_data['body'] and b'\r\nfalse\r\n' in req_data['body']
    assert req_data['headers']['Authorization']=='Bearer test_photoroom_key'
    assert cutout.size==(100,150) and cutout.getpixel((10,10))[3]==0
    with patch('online_ai.urlopen',side_effect=HTTPError(API_URL,401,'not authorized',None,None)):
        try:remove_background(image,'top_secret')
        except AIServiceError as exc:assert 'top_secret' not in str(exc) and 'key' in str(exc)
        else:raise AssertionError('401 should fail and not mask as good AI')
    with patch('online_ai.urlopen',side_effect=URLError('failure')):
        try:remove_background(image,'top_secret')
        except AIServiceError as exc:assert 'ইন্টারনেট' in str(exc)
        else:raise AssertionError('Offline should fail and not silently downgrade to OpenCV')
    with TemporaryDirectory() as t:
        src=Path(t)/'photo.jpg';image.save(src)
        with patch('engine.remove_background',return_value=cutout) as call:
            processed=enhance_image(src,background='studio',background_provider='bgclear',ai_key='fake_key')
            assert call.call_count==1
            assert processed.info['background_method']=='bgclear_online_ai_preview'
            assert processed.getpixel((0,0))==(49,90,174)
            assert processed.getpixel((90,50))==(255,0,0)
            meta=make_photo_layout(src,Path(t)/'layout.pdf',preset='passport',count=4,background='white',background_provider='auto',ai_key='fake_key',paper_orientation='landscape')
            assert meta['background_method']=='bgclear_online_ai_preview'
            assert meta['photo_dpi']==300 and meta['photo_pixels']==[450,570]
            with fitz.open(Path(t)/'layout.pdf') as pdf:
                assert pdf[0].rect.width>pdf[0].rect.height
        with patch('engine.remove_background') as call:
            processed=enhance_image(src,background='original',background_provider='auto',ai_key='fake_key')
            assert call.call_count==0 and processed.info['background_method']=='original'
    print('PASS: BG Clear preview request format; transparent PNG and color composite; API/network errors; portrait layout on landscape PDF')

if __name__=='__main__':run()
