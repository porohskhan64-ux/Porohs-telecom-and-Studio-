"""Run with `python tests/test_extra_tools.py` from the project directory."""
from pathlib import Path
from tempfile import TemporaryDirectory
import fitz
from PIL import Image,ImageDraw
from extra_tools import make_nid_sheet,pdf_action,camera_scan,skin_soften,batch_photo_sheet

def run():
    with TemporaryDirectory() as temp:
        d=Path(temp)
        for i in range(3):
            im=Image.new('RGB',(900,580),'#dedede')
            draw=ImageDraw.Draw(im)
            draw.rectangle((55,50,830,530),outline='#10356a',width=8,fill='#def4ff')
            draw.text((130,200),f'READABLE ID TEST {i}',fill='#000000')
            im.save(d/f'{i}.jpg')
        meta=make_nid_sheet(d/'0.jpg',d/'1.jpg',d/'nid.pdf',auto_crop=True)
        assert meta['card_mm']==[85.6,54] and meta['paper_mm']==[210,297]
        with fitz.open(d/'nid.pdf') as doc:
            assert doc.page_count==1
            assert abs(doc[0].rect.width-210*72/25.4)<.02
        scan=camera_scan(d/'0.jpg',d/'scan.jpg',mode='bw')
        assert scan['width']>200
        Image.open(d/'scan.jpg').verify()
        with fitz.open() as doc:
            for i in range(5):doc.new_page().insert_text((50,80),f'PAGE-{i}')
            doc.save(d/'a.pdf')
        with fitz.open() as doc:
            doc.new_page().insert_text((50,80),'another')
            doc.save(d/'b.pdf')
        assert pdf_action([d/'a.pdf',d/'b.pdf'],d/'merged.pdf','merge')['pages']==6
        assert pdf_action([d/'a.pdf'],d/'split.pdf','split',pages='1,3-4')['pages']==3
        assert pdf_action([d/'a.pdf'],d/'optimized.pdf','compress')['pages']==5
        assert batch_photo_sheet([d/'0.jpg',d/'1.jpg',d/'2.jpg'],d/'batch.pdf',copies_each=3)['copies']==9
        with fitz.open(d/'batch.pdf') as doc:assert doc.page_count>=1
        assert skin_soften(Image.open(d/'0.jpg'),0.3).size==(900,580)
    print('PASS: NID 85.6×54 mm, camera scan, PDF merge/split/optimize, photo batch, skin softness')

if __name__=='__main__':run()
