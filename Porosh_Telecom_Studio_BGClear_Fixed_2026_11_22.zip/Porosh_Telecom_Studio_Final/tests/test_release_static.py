from pathlib import Path
base=Path(__file__).resolve().parents[1]
server=(base/'app.py').read_text(encoding='utf8')
js=(base/'static/studio.js').read_text(encoding='utf8')
job=(base/'templates/job.html').read_text(encoding='utf8')
ui=(base/'templates/studio.html').read_text(encoding='utf8')
assert "@app.get('/api/network')" in server
assert "@app.get('/qr.png')" in server
assert "refreshQR()" in js and 'liveQr' in ui
assert "d.status!=='submitted'" in job
assert 'happyCartoon' in job and 'config.phone' in job
print('PASS: QR IP refresh and success-only cartoon screen wired')
