@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Porosh Studio - Python 3.12 launcher
echo.
py -3.12 --version >nul 2>&1
if errorlevel 1 (
 echo [ERROR] Python 3.12 64-bit is not installed.
 echo Install Python 3.12 for Windows, then try again.
 echo Official: https://www.python.org/downloads/release/python-31210/
 pause
 exit /b 1
)
if not exist .venv312\Scripts\python.exe (
 echo Creating separate Python 3.12 environment...
 py -3.12 -m venv .venv312
 if errorlevel 1 (
  echo [ERROR] Could not create the Python 3.12 environment.
  pause
  exit /b 1
 )
)
if not exist .venv312\.porosh_dependencies_ok (
 echo First start: installing free Python packages. Internet needed once...
 .venv312\Scripts\python.exe -m pip install -r requirements.txt
 if errorlevel 1 (
  echo [ERROR] Package install failed. Check internet and restart.
  pause
  exit /b 1
 )
 echo OK> .venv312\.porosh_dependencies_ok
)
echo Packages ready.
echo Opening Porosh Studio...
start "" "http://127.0.0.1:5000"
.venv312\Scripts\python.exe app.py
pause
