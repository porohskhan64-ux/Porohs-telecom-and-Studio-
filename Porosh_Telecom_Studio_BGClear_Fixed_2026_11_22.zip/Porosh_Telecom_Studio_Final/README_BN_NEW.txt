নতুন ফিচার-ইন্টিগ্রেটেড সংস্করণের জন্য README_READ_ME_FIRST_BN.md আগে পড়ুন।

পরশ টেলিকম অ্যান্ড স্টুডিও — চূড়ান্ত পরীক্ষাযোগ্য সোর্স-কোড প্যাকেজ
==================================================
এটি Windows 10-এর জন্য সম্পাদনাযোগ্য Python Flask প্রিন্টিং অ্যাপ।
মূল পুরনো v2 ZIP backup: legacy/ORIGINAL_QR_v2_backup.zip

১। শুরু করুন
* Windows 10-এ Python 3.11 বা 3.12 ইনস্টল করুন (Add Python to PATH)।
* Epson L130-এর সঠিক Windows Printer Driver, SumatraPDF এবং LibreOffice (Word এর জন্য) ইনস্টল করুন।
* ZIP Extract করে START_WINDOWS.bat ডাবল ক্লিক করুন। প্রথমবার ইন্টারনেট লাগে।
* পরে START_SERVER.bat দিয়ে চালাতে পারবেন।
* PC: http://127.0.0.1:5000; একই Wi-Fi-তে ফোন: http://PC-IP:5000
* PC-তে /admin খুলে ডিফল্ট Epson L130 প্রিন্টার সেট করুন এবং auto-print ON রাখুন।
* QR দেখতে ও প্রিন্ট করতে হোমপেজের QR ট্যাব ব্যবহার করুন। IP পাল্টালে QR নতুন হবে।

২। এখন বাস্তবে কোডে যা রয়েছে
* নীল-কালো responsive বাংলা ওয়েবসাইট ও CSS 3D নামে লোগো
* JPG/PNG/WEBP/BMP/TIFF ও PDF/Word/Office আপলোড
* পাসপোর্ট 35x45 mm, স্ট্যাম্প 25x30 mm, কাস্টম ছবির সাইজ
* প্রথমে চার কপি; +/− বোতামে এক কপি করে বাড়ানো-কমানো
* A4, A5, A6, Letter, Legal, Custom mm পেজ; কাগজের Portrait/Landscape
* ছবির Portrait/Landscape আলাদা; কাগজের ওপর থেকে মার্জিন রেখে সাজানো; একাধিক পৃষ্ঠা
* ডিফল্ট ON Auto Enhance, চোখ শনাক্ত করে ছোট কাত ছবি Auto Straighten, ম্যানুয়াল ঘোরানো, কনট্রাস্ট/উজ্জ্বলতা/শার্পনেস
* DOC/DOCX এবং কিছু Office ফাইল LibreOffice-এ PDF রূপান্তর করে প্রিভিউ
* PDF/Word-এর পৃষ্ঠা all বা 1,3,5-7 বেছে প্রিন্ট PDF বানানো
* ফোনে তোলা ডকুমেন্ট ছবি ফিট করা, অটো ক্লিন; optional OpenCV স্কিউ সংশোধন
* Print Preview, PDF খোলা/সেভ করা; কপি, কালার/BW, প্রিন্টার নির্বাচন
* একই Wi-Fi-তে মোবাইল থেকে QR দিয়ে ওয়েবসাইট এবং প্রিন্ট (অতিরিক্ত approval নয়)
* Windows SumatraPDF-তে print-job dispatch; কাস্টমারকে ধন্যবাদ বার্তা ও নম্বর
* Settings.json-এ দোকানের নাম, ফোন, বার্তা, job limits; /admin থেকে কিছু সেটিংস
* Optional rembg ইনস্টল থাকলে সাদা/স্টুডিও/স্কাই ব্যাকগ্রাউন্ড অপশন

৩। কোন কাজ সীমাবদ্ধ/এখনো পুরো পরীক্ষিত নয়
* Epson L130 Windows 10/USB থেকে বাস্তব প্রিন্ট পরীক্ষা করা হয়নি।
* মুদ্রণ কিউতে পাঠানো successful হলে আসল প্রিন্ট শেষ হওয়া নিশ্চয়তা নয়।
* Draft/High/Super High কোয়ালিটি সফটওয়্যার থেকে driver-এ প্রয়োগ হয় না;
  Windows Epson Printing Preferences-এ সেট করুন।
* কাস্টম পেপার ড্রাইভারের Paper Size-এ আলাদা করে সমান মাপ দিয়ে নিন।
* চোখ না পাওয়া ছবিতে অটো ঘোরানোর নিশ্চয়তা নেই; advanced AI face restoration,
  স্বয়ংক্রিয় document perspective scanning এখনো করা হয়নি।
* AutoEnhance জেনারেটিভ AI নয়; ছবিতে হালকা আলোর/রঙের পরিবর্তন করে।
* AI Background Removal শুধুমাত্র optional; INSTALL_AI_OPTIONAL.bat ইনস্টল,
  এবং প্রথম ব্যবহারে ONNX AI model download লাগতে পারে। ভালো কাটার নিশ্চয়তা নেই।
* OpenCV প্রধান requirements-এ যোগ করা হয়েছে। মুখ/চোখের অবস্থান স্পষ্ট না হলে অটো ফটো সোজা না করে আসল ছবি রাখবে।
* PDF প্রিভিউ মোবাইল ব্রাউজারের PDF viewer-এর উপর নির্ভর করে।
* Print job history সার্ভার restart করলে হারিয়ে যাবে (ফাইল ২৪ ঘণ্টা পরে নতুন আপলোডে পরিষ্কার হয়)।

৪। নিরাপত্তা
* অজানা লোককে একই Wi-Fi-তে রাখবেন না; আলাদা guest Wi-Fi উপকারী।
* QR self-print আপনার নির্দেশ অনুযায়ী আলাদা অনুমতি ছাড়া চলে। তাই 25 MB,
  3 job/min/IP, 10 copies, 100 printed-pages/request limit আছে।
* অফিস ফাইল অচেনা হলে LibreOffice দিয়ে রূপান্তরে সতর্ক থাকুন।
* Port forwarding / Internet থেকে সরাসরি সার্ভার খুলবেন না।
* Windows Firewall-এ শুধু Private Network-এ Python/port 5000 allow করুন।
* Wi-Fi hotspot-এ device isolation থাকলে phone থেকে সার্ভার খুলবে না।

৫। ভবিষ্যতে যেভাবে বদলাবেন
* web design: templates/studio.html এবং static/studio.css
* browser actions: static/studio.js
* Flask upload/print/QR: app.py
* photo crop, sizing, PDF layout: engine.py
* Epson/Sumatra Windows print adapter: printer.py
* shop name/phone/message: settings.json অথবা PC localhost /admin
* requirements.txt ও INSTALL_AI_OPTIONAL.bat অ্যাড-অন লাইব্রেরি
* পরীক্ষা: python tests/test_engine.py (Python path প্রকল্প ফোল্ডার থেকেই দিন)

৬। সফটওয়্যার ইনস্টলার লিংক (কোনো ড্রাইভার ফাইল ZIP-এর সঙ্গে নেই)
Epson L130 Windows driver: https://download-center.epson.com/download/?device_id=L130+Series&module_id=c10aa106-17d6-4e23-bd50-03cb09220718%3A2.60.00&os=WIN1064&region=GB
Sumatra PDF: https://www.sumatrapdfreader.org/download-free-pdf-viewer
LibreOffice: https://www.libreoffice.org/download/
GIMP: https://www.gimp.org/downloads/
Python: https://www.python.org/downloads/windows/

পরীক্ষার তথ্য: Python engine tests PASS — A4 4-photo, A5 landscape 8-photo,
custom landscape paper, selected pages 1/3/5, document image PDF.
এই পরিবেশে Windows/Epson প্রিন্ট পরীক্ষা করা হয়নি।
