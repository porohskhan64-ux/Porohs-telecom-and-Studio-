# Porosh Telecom & Studio — BG Clear API সেটআপ
তারিখ: ২২ নভেম্বর ২০২৬

## BG Clear API কীভাবে কাজ করে
- এই সংস্করণে Background Remove-এর অনলাইন সেবা হিসেবে **BG Clear** ব্যবহার করা হয়; Photoroom API ব্যবহার করা হয় না।
- API endpoint: `https://www.bgclear.ai/api/v1/remove`
- Authentication: `Authorization: Bearer <আপনার BG Clear API key>`
- Multipart fields: `image_file`, `size=preview`, `format=png`, `bg_color=transparent`, `crop=false`, `store=false`।
- `preview` সর্বোচ্চ ৮০০ পিক্সেল পর্যন্ত ফ্রি; Full resolution স্বয়ংক্রিয়ভাবে চাওয়া হয় না।
- BG Clear API-এর অনুমোদিত `format`: `png`, `webp`, `jpg`; এই অ্যাপ স্বচ্ছ ব্যাকগ্রাউন্ড রাখার জন্য `png` চায়।

## Windows-এ সেটআপ
1. অ্যাপ বন্ধ করে ZIP আলাদা ফোল্ডারে Extract করুন।
2. `START_WINDOWS.bat` চালান।
3. দোকানের কম্পিউটারে `http://127.0.0.1:5000/admin` খুলুন এবং অ্যাডমিন লগইন করুন।
4. **অনলাইন AI — BG Clear API** অংশে BG Clear Dashboard থেকে তৈরি করা API Key পেস্ট করে **API key সংরক্ষণ / পরিবর্তন** চাপুন।
5. মূল পেজে ছবি আপলোড করুন; Background-এ White বা অন্য রঙ বেছে BG Clear Online AI নির্বাচন করে Preview তৈরি করুন।
6. প্রিন্টের আগে PDF প্রিভিউ পরীক্ষা করুন। প্রথমে একটি পরীক্ষামূলক ছবি ব্যবহার করুন।

## `Invalid format` বা API error হলে
- JPG, PNG বা WebP-এর একটি সাধারণ ছবি দিয়ে পরীক্ষা করুন।
- ছবিটি ২৫ MB ও ৫০ মেগাপিক্সেলের সীমার মধ্যে রাখুন।
- Key যেন সম্পূর্ণ কপি হয়; শুরু/শেষে স্পেস বা newline না থাকে।
- API key সংরক্ষণ সফল হওয়া মানে API call সফল হওয়া নয়; Preview তৈরি করে API response পরীক্ষা করতে হবে।
- নতুন কোডে BG Clear-এর JSON error code পড়ে নির্দিষ্ট বার্তা দেখানো হয়: `unsupported_format` হলে ছবির ফরম্যাট; `invalid_request` হলে request parameter সমস্যা।
- `401/403` হলে key বা অনুমোদন; `429` হলে rate limit; `503` হলে সার্ভার ব্যস্ত।
- Key ZIP, HTML, PDF বা backup-এ রাখা হয় না; এটি `data/bgclear_api.key` ফাইলে থাকে। Key কাউকে পাঠাবেন না।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- Preview output ৮০০ পিক্সেল পর্যন্ত; প্রিন্টের নির্ধারিত মাপে বড় করলে অতিরিক্ত আসল detail তৈরি হয় না।
- API-তে ছবি BG Clear সার্ভারে পাঠানো হয়। গ্রাহকের ছবি পাঠানোর আগে সম্মতি নিন।
- API key ব্যবহারকারীর নিজের; বাস্তব API পরীক্ষা করতে ইন্টারনেট ও সচল key প্রয়োজন।
- API docs: https://www.bgclear.ai/api-docs/
