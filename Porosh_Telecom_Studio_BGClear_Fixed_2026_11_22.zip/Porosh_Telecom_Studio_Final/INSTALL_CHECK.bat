@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .venv312\Scripts\python.exe (
 echo START_WINDOWS.bat first run korun.
 pause
 exit /b 1
)
.venv312\Scripts\python.exe -c "from app import app; from printer import printers,find_program; print('Application imports OK'); print('Printers:',printers()); print('Sumatra:',find_program('sumatra')); print('LibreOffice:',find_program('libreoffice'))"
set "PYTHONPATH=%~dp0"
.venv312\Scripts\python.exe tests\test_engine.py
pause
