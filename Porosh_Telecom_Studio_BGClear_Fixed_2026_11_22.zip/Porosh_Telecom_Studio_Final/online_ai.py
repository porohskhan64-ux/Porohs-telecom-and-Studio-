"""BG Clear remote-only transparent background removal (free preview mode)."""
from __future__ import annotations
from io import BytesIO
import secrets
from urllib.error import HTTPError, URLError
import json
from urllib.request import Request, urlopen
from PIL import Image, UnidentifiedImageError

API_URL = 'https://www.bgclear.ai/api/v1/remove'
MAX_RESPONSE = 35 * 1024 * 1024

class AIServiceError(ValueError):
    """Show safe errors without exposing API credentials or remote response."""

def remove_background(image: Image.Image, api_key: str) -> Image.Image:
    if not api_key or any(ch.isspace() for ch in api_key):
        raise AIServiceError('BG Clear API key সেট করা নেই। /admin প্যানেলে key বসান।')
    request_image=image.convert('RGB')
    if max(request_image.size)>6000:
        request_image=request_image.copy()
        request_image.thumbnail((6000,6000), Image.Resampling.LANCZOS)
    jpg=BytesIO()
    request_image.save(jpg,format='JPEG',quality=94,subsampling=0)
    boundary='----PoroshBgClear'+secrets.token_hex(16)
    parts=[]
    def field(name,value):
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode('ascii'))
    field('size','preview')  # Always free preview; never use 'auto' or 'full' implicitly.
    field('format','png')  # BG Clear accepts png, webp or jpg; PNG preserves transparency.
    field('bg_color','transparent')
    field('crop','false')
    field('store','false')
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="image_file"; filename="photo.jpg"\r\nContent-Type: image/jpeg\r\n\r\n'.encode('ascii'))
    parts.extend((jpg.getvalue(), b'\r\n', f'--{boundary}--\r\n'.encode('ascii')))
    req=Request(API_URL,data=b''.join(parts),method='POST',headers={
        'Authorization':'Bearer '+api_key,
        'Content-Type':f'multipart/form-data; boundary={boundary}',
        'Accept':'image/png'
    })
    try:
        with urlopen(req,timeout=45) as response:
            if not response.headers.get('Content-Type','image/png').lower().startswith('image/'):
                raise AIServiceError('BG Clear থেকে ছবি আসেনি। সার্ভার বা API key পরীক্ষা করুন।')
            data=response.read(MAX_RESPONSE+1)
    except HTTPError as exc:
        # BG Clear returns structured JSON errors. Preserve the safe server
        # message so format/parameter problems are diagnosable instead of
        # hiding every HTTP 400 behind a generic "Invalid format".
        try:
            payload=json.loads(exc.read(64 * 1024).decode('utf-8','replace'))
            detail=payload.get('error',{}) if isinstance(payload,dict) else {}
            code=str(detail.get('code',''))[:80]
            message=str(detail.get('message',''))[:300]
        except (ValueError,TypeError,AttributeError):
            code=message=''
        if exc.code in (401,403):
            raise AIServiceError('BG Clear API key ভুল, বাতিল, অথবা এই endpoint-এর জন্য অনুমোদিত নয়।') from None
        if exc.code==402:
            raise AIServiceError('BG Clear ক্রেডিট/প্ল্যান সমস্যা। Preview mode ব্যবহার হচ্ছে কি না পরীক্ষা করুন।') from None
        if exc.code==429:
            raise AIServiceError('BG Clear অনুরোধের সীমা পূর্ণ হয়েছে। কিছুক্ষণ পরে চেষ্টা করুন।') from None
        if exc.code==503:
            raise AIServiceError('BG Clear সার্ভার ব্যস্ত। কিছুক্ষণ পরে আবার চেষ্টা করুন।') from None
        if code=='unsupported_format':
            raise AIServiceError('BG Clear ছবির ফাইল ফরম্যাট গ্রহণ করেনি। JPG, PNG বা WebP ছবি দিয়ে আবার চেষ্টা করুন।') from None
        if code=='invalid_request':
            raise AIServiceError('BG Clear অনুরোধের কোনো প্যারামিটার ভুল: '+(message or 'API ডকুমেন্টেশন মিলিয়ে দেখুন')) from None
        if message:
            raise AIServiceError(f'BG Clear HTTP {exc.code}: {message}') from None
        raise AIServiceError(f'BG Clear সার্ভারে HTTP {exc.code} ত্রুটি।') from None
    except (TimeoutError, URLError, OSError):
        raise AIServiceError('BG Clear সার্ভারে সংযোগ হয়নি। ইন্টারনেট পরীক্ষা করুন।') from None
    if len(data)>MAX_RESPONSE:raise AIServiceError('BG Clear-এর ছবির আকার অস্বাভাবিক বড়।')
    try:
        with Image.open(BytesIO(data)) as raw:
            if raw.format!='PNG':raise AIServiceError('BG Clear PNG দেয়নি।')
            cutout=raw.convert('RGBA')
    except (OSError,UnidentifiedImageError,ValueError):
        raise AIServiceError('BG Clear-এর উত্তরটি সঠিক PNG নয়।') from None
    if cutout.getchannel('A').getextrema()==(255,255):
        raise AIServiceError('BG Clear ছবিতে স্বচ্ছ ব্যাকগ্রাউন্ড পাওয়া যায়নি।')
    ratio_in=image.width/image.height
    ratio_out=cutout.width/cutout.height
    if abs(ratio_in/ratio_out-1)>.015:
        raise AIServiceError('BG Clear ছবির অনুপাত বদলে দিয়েছে; নিরাপত্তার জন্য বাতিল।')
    if cutout.size!=image.size:
        # Scale back to the user's chosen print dimensions; no paid full-res request.
        cutout=cutout.resize(image.size,Image.Resampling.LANCZOS)
    return cutout
