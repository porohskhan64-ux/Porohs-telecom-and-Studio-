@echo off
cd /d "%~dp0"
if exist .venv312\Scripts\python.exe (
 .venv312\Scripts\python.exe generate_qr.py
) else (
 echo First run START_WINDOWS.bat
 pause
)
