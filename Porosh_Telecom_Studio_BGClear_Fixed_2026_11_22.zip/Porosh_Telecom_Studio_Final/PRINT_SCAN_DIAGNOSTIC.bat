@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .venv312\Scripts\python.exe (
 echo First run START_WINDOWS.bat to install free packages.
 pause
 exit /b 1
)
.venv312\Scripts\python.exe -c "from printer import printers,default_printer,find_program;from scanner import devices;print('Printers installed in Windows:',printers());print('Default:',default_printer());print('Windows WIA scanners:',devices());print('SumatraPDF:',find_program('sumatra'));print('LibreOffice:',find_program('libreoffice'))"
pause
