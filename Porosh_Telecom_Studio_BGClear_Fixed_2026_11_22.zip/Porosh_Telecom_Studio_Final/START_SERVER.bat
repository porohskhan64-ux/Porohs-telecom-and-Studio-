@echo off
cd /d "%~dp0"
if exist .venv312\Scripts\python.exe (
 .venv312\Scripts\python.exe app.py
) else (
 echo First run START_WINDOWS.bat to install requirements.
 pause
)
