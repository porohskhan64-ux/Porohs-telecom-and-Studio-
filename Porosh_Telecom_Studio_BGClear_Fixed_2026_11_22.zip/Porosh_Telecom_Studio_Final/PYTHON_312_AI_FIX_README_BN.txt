পরশ টেলিকম অ্যান্ড স্টুডিও — Python 3.12 / AI ইনস্টল সমস্যার সংশোধিত সংস্করণ

কেন: আপনার PC-তে py -0p অনুযায়ী Python 3.15 ছিল। কিছু AI প্যাকেজে Python 3.15-এর জন্য binary wheel না থাকায় scikit-image source থেকে build হতে চাচ্ছিল এবং C/C++ compiler পাওয়া যায়নি।

১. Python 3.12 (64-bit) ইনস্টল করুন: https://www.python.org/downloads/release/python-31210/
২. Windows Command Prompt-এ লিখুন: py -3.12 --version
৩. আগের সার্ভার বন্ধ করুন। নতুন এই ZIP Extract করুন।
৪. Porosh_Telecom_Studio_Final ফোল্ডারে START_WINDOWS.bat চালান। প্রথমবার ইন্টারনেট লাগবে।
৫. বেস অ্যাপ চালু হলে সেটা বন্ধ করতে Ctrl+C দিন।
৬. INSTALL_AI_OPTIONAL.bat চালান। সফল বার্তা না পেলে স্ক্রিনশট নিন।
৭. আবার START_WINDOWS.bat চালিয়ে ওয়েবসাইটে চেষ্টা করুন।

সতর্কতা: এই সংস্করণে .venv312 নামে আলাদা পরিবেশ তৈরি হয়। আগের .venv বা Python 3.15 মুছতে হবে না। অন্য কোনো ZIP-এর BAT ফাইলের সঙ্গে মিশিয়ে ব্যবহার করবেন না।
বাকি অ্যাপের ফিচার অপরিবর্তিত; এই আপডেট শুধু Windows Python version নির্বাচন এবং AI install failure রিপোর্ট সংশোধন করে।
Epson L130-এর বাস্তব প্রিন্ট এই পরিবেশে পরীক্ষা হয়নি। AI background model প্রথম ব্যবহারকালে আলাদাভাবে ডাউনলোড হতে পারে।
