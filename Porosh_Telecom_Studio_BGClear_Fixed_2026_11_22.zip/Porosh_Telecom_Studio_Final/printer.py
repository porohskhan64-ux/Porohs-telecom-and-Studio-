"""Windows driver and SumatraPDF adapter. Dispatch success is NOT proof of physical printing."""
import os,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def printers():
    if os.name!='nt':return []
    try:
        import win32print
        flags=win32print.PRINTER_ENUM_LOCAL|win32print.PRINTER_ENUM_CONNECTIONS
        return sorted(set(p[2] for p in win32print.EnumPrinters(flags)))
    except Exception:return []

def default_printer():
    if os.name=='nt':
        try:
            import win32print
            return win32print.GetDefaultPrinter()
        except Exception:pass
    return ''

def find_program(name):
    if name=='sumatra':
        choices=[ROOT/'SumatraPDF.exe',Path(r'C:\Program Files\SumatraPDF\SumatraPDF.exe'),Path(r'C:\Program Files (x86)\SumatraPDF\SumatraPDF.exe'),Path(os.environ.get('LOCALAPPDATA','C:\\Users\\Public'))/'SumatraPDF'/'SumatraPDF.exe']
        extra=['SumatraPDF.exe','SumatraPDF']
    elif name=='libreoffice':
        choices=[Path(r'C:\Program Files\LibreOffice\program\soffice.exe'),Path(r'C:\Program Files (x86)\LibreOffice\program\soffice.exe')]
        extra=['soffice.exe','soffice']
    else:return None
    for p in choices:
        if p.is_file():return str(p)
    for e in extra:
        v=shutil.which(e)
        if v:return v
    return None

def convert_office(source,outdir):
    office=find_program('libreoffice')
    if not office:raise RuntimeError('LibreOffice ইনস্টল করা নেই বা খুঁজে পাওয়া যায়নি')
    import tempfile
    # A separate LibreOffice profile avoids conflicting with an open Word document editor.
    with tempfile.TemporaryDirectory(prefix='porosh-lo-') as profile:
        profile_uri=Path(profile).as_uri()
        cmd=[office,'-env:UserInstallation='+profile_uri,'--headless','--convert-to','pdf','--outdir',str(outdir),str(source)]
        p=subprocess.run(cmd,capture_output=True,timeout=100)
    target=Path(outdir)/(Path(source).stem+'.pdf')
    if p.returncode or not target.is_file():raise RuntimeError('LibreOffice দিয়ে PDF বানানো যায়নি; ফাইলটি পরীক্ষা করুন')
    return target

def dispatch_pdf(pdf,printer,copies=1,color='color',paper='A4',quality='normal'):
    if os.name!='nt':raise RuntimeError('বাস্তব প্রিন্টিংয়ের জন্য Windows লাগবে')
    if printer not in printers():raise RuntimeError('নির্বাচিত প্রিন্টার Windows-এ পাওয়া যাচ্ছে না')
    sumatra=find_program('sumatra')
    copies=int(copies)
    if not 1<=copies<=10:raise RuntimeError('একবারে সর্বোচ্চ ১০ কপি')
    if color not in {'color','bw'}:raise RuntimeError('রঙের অপশন সঠিক নয়')
    if paper not in {'A4','A5','A6','Letter','Legal','custom'}:raise RuntimeError('কাগজের অপশন সঠিক নয়')
    if quality not in {'draft','normal','high','super'}:raise RuntimeError('প্রিন্ট কোয়ালিটি সঠিক নয়')
    # Only non-normal quality needs per-job GDI DEVMODE control. Never pretend
    # a Sumatra argument applies a driver quality preset when it does not.
    if quality!='normal' or not sumatra:
        from driver_print import print_pdf_driver
        return print_pdf_driver(pdf,printer,copies,color,paper,quality)
    # Sumatra supports paper presets & color/monochrome, but not driver quality.
    # Driver paper format for custom page MUST be set by the user in Windows.
    settings=[f'{copies}x','fit','monochrome' if color=='bw' else 'color']
    if paper!='custom':settings.append('paper='+paper)
    cmd=[sumatra,'-silent','-print-to',printer,'-print-settings',','.join(settings),str(pdf)]
    p=subprocess.run(cmd,capture_output=True,timeout=120,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    if p.returncode!=0:raise RuntimeError('Windows প্রিন্ট কমান্ড ব্যর্থ হয়েছে। ড্রাইভার/কিউ পরীক্ষা করুন')
    return {'status':'submitted','driver_quality_applied':False,'detail':'Windows print queue-তে কমান্ড পাঠানো হয়েছে; কাগজ বের হওয়া নিশ্চিত নয়। ড্রাইভারে quality নির্বাচন করুন।'}
