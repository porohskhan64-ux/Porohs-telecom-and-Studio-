@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Porosh Studio now includes FREE offline OpenCV background cleanup.
echo No paid API, no optional AI model and no separate purchase are required.
echo Hair and complex borders can be imperfect. Test photos before printing.
echo To install the basic packages, use START_WINDOWS.bat first.
pause
