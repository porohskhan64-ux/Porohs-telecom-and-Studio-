"""PDF layouts and conservative photo/document image processing.
No generative face enhancement, face/body reshaping, or silent fake background removal.
"""
from __future__ import annotations
import math
import re
from pathlib import Path
from PIL import Image, ImageOps, ImageEnhance, ImageFilter
from online_ai import remove_background
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.utils import ImageReader
from reportlab.lib.colors import HexColor
import fitz

PAPER_MM = {'A4':(210,297), 'A5':(148,210), 'A6':(105,148), 'Letter':(215.9,279.4), 'Legal':(215.9,355.6)}
MM_PT = 72/25.4
IMAGE_EXT = {'.jpg','.jpeg','.png','.webp','.bmp','.tif','.tiff'}
DOC_EXT = {'.pdf','.doc','.docx','.odt','.rtf','.txt','.xls','.xlsx','.ppt','.pptx'}

def paper_dimensions(paper='A4', orientation='portrait', custom_w=210, custom_h=297):
    if paper == 'custom':
        w,h = float(custom_w),float(custom_h)
        if not 50 <= w <= 420 or not 50 <= h <= 594:
            raise ValueError('কাস্টম কাগজের মাপ 50–420 × 50–594 মিমি হতে হবে')
    elif paper in PAPER_MM: w,h=PAPER_MM[paper]
    else: raise ValueError('অজানা কাগজের মাপ')
    if orientation=='landscape': return max(w,h),min(w,h)
    if orientation!='portrait': raise ValueError('পেজের দিক সঠিক নয়')
    return min(w,h),max(w,h)

def parse_pages(spec, n):
    if not spec or spec.strip().lower()=='all':return list(range(n))
    out=[]; seen=set()
    for x in spec.replace(' ', '').split(','):
        if not x:raise ValueError('পৃষ্ঠা নির্বাচন সঠিক নয়')
        if re.fullmatch(r'\d+', x): ids=[int(x)]
        elif re.fullmatch(r'\d+-\d+',x):
            a,b=map(int,x.split('-'))
            if b<a:raise ValueError('পৃষ্ঠা রেঞ্জ ছোট থেকে বড় দিন')
            ids=list(range(a,b+1))
        else:raise ValueError('পৃষ্ঠা লিখুন যেমন 1,3,5-7')
        for p in ids:
            if p<1 or p>n:raise ValueError(f'পৃষ্ঠা {p} নেই; মোট {n} পৃষ্ঠা')
            if p not in seen:seen.add(p);out.append(p-1)
    if not out or len(out)>100:raise ValueError('১–১০০ পৃষ্ঠা নির্বাচন করুন')
    return out

def photo_size(preset, w, h):
    if preset in ('passport','scan'):return 38.1,48.26
    if preset == 'stamp':return 25.,30.
    if preset == 'custom':
        w,h=float(w),float(h)
        if not (.5<=w<=300 and .5<=h<=300):raise ValueError('ছবির মাপ সঠিক নয়')
        return w,h
    raise ValueError('অজানা ছবির সাইজ')


def estimate_photo_tilt(image):
    """Estimate in-plane head tilt from a confident eye pair.

    This is conservative: if two credible eyes cannot be found, leave the
    picture untouched. No face geometry is reconstructed or reshaped.
    Returns (correction_degrees, detection_status).
    """
    try:
        import cv2
        import numpy as np
    except ImportError:
        return 0.0, 'opencv_missing'
    try:
        gray = cv2.cvtColor(np.asarray(image.convert('RGB')), cv2.COLOR_RGB2GRAY)
        limit = 1400
        if max(gray.shape)>limit:
            ratio = limit/max(gray.shape)
            gray = cv2.resize(gray, None, fx=ratio, fy=ratio, interpolation=cv2.INTER_AREA)
        gray = cv2.equalizeHist(gray)
        cascade_dir = cv2.data.haarcascades
        face_cascade = cv2.CascadeClassifier(str(Path(cascade_dir)/'haarcascade_frontalface_default.xml'))
        eye_cascade = cv2.CascadeClassifier(str(Path(cascade_dir)/'haarcascade_eye.xml'))
        if face_cascade.empty() or eye_cascade.empty():
            return 0.0, 'model_unavailable'
        faces = face_cascade.detectMultiScale(gray, scaleFactor=1.10, minNeighbors=5, minSize=(60,60))
        if len(faces)==0:
            return 0.0, 'no_confident_face'
        # Largest visible frontal face, avoid distant background faces.
        x,y,w,h = max(faces, key=lambda f:int(f[2])*int(f[3]))
        eyetop = y + int(h*.15)
        eyebottom = y + int(h*.63)
        eye_band = gray[eyetop:eyebottom,x:x+w]
        eyes = eye_cascade.detectMultiScale(eye_band, scaleFactor=1.08, minNeighbors=5, minSize=(max(12,int(w*.10)),max(10,int(h*.08))))
        candidates=[]
        for ex,ey,ew,eh in eyes:
            cx=x+ex+ew/2; cy=eyetop+ey+eh/2
            if x+w*.08<=cx<=x+w*.92 and y+h*.16<=cy<=y+h*.62:
                candidates.append((cx,cy,ew,eh))
        pairs=[]
        for i,a in enumerate(candidates):
            for b in candidates[i+1:]:
                left,right = sorted((a,b),key=lambda t:t[0]); dx=right[0]-left[0]; dy=right[1]-left[1]
                if not (w*.25<=dx<=w*.80):continue
                if abs(dy)>h*.20:continue
                ratio=max(left[2],right[2])/max(1,min(left[2],right[2]))
                if ratio>1.7:continue
                mid=(left[0]+right[0])/2
                if abs(mid-(x+w*.5))>w*.18:continue
                deg=math.degrees(math.atan2(dy,dx))
                if abs(deg)>12:continue  # don't make large speculative changes
                score=dx/w-abs(mid-(x+w*.5))/w*.4-abs(dy)/h*.2
                pairs.append((score,deg))
        if not pairs:return 0.0, 'no_confident_eyes'
        angle=max(pairs,key=lambda p:p[0])[1]
        if abs(angle)<.8:return 0.0,'already_level'
        # Pillow positive angles rotate counter-clockwise; positive eye-line
        # slope in image-down pixel coordinates needs counter-clockwise rotation.
        return round(angle,2), 'detected'
    except (ValueError,cv2.error):
        return 0.0, 'detector_error'

def smart_face_crop_center(image, target_ratio):
    """Find a safe crop center; avoid hiding a confidently detected head.

    Returns a normalized (x,y) center and a status. No generated pixels.
    """
    default=(.5,.43)
    try:
        import cv2
        import numpy as np
        im=np.asarray(image.convert('RGB'))
        h,w=im.shape[:2]
        scale=min(1.,1000/max(w,h))
        small=cv2.resize(im,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA) if scale<1 else im
        grey=cv2.cvtColor(small,cv2.COLOR_RGB2GRAY)
        detector=cv2.CascadeClassifier(str(Path(cv2.data.haarcascades)/'haarcascade_frontalface_default.xml'))
        faces=detector.detectMultiScale(grey,scaleFactor=1.12,minNeighbors=6,minSize=(45,45))
        if len(faces)!=1:return default,'ambiguous_face' if len(faces)>1 else 'face_not_found'
        x,y,fw,fh=map(float,faces[0]); x/=scale;y/=scale;fw/=scale;fh/=scale
        # Reserve headroom above the face and chest space below the chin.
        cx=(x+fw*.5)/w
        cy=(y+fh*1.42)/h
        if target_ratio<=0:return default,'invalid_ratio'
        cropw=min(w,h*target_ratio);croph=min(h,w/target_ratio)
        # Never let the detected face touch the crop boundary.
        left=x-fw*.14;right=x+fw*1.14;top=y-fh*.43;bottom=y+fh*1.27
        if right-left>cropw*.96 or bottom-top>croph*.96:
            return default,'face_too_large'
        cx=max((right-cropw*.94+cropw/2)/w,min((left+cropw*.94-cropw/2)/w,cx)) if cropw<w else .5
        cy=max((bottom-croph*.94+croph/2)/h,min((top+croph*.94-croph/2)/h,cy)) if croph<h else .5
        cx=max(cropw/(2*w),min(1-cropw/(2*w),cx))
        cy=max(croph/(2*h),min(1-croph/(2*h),cy))
        return (float(cx),float(cy)),'face_detected'
    except (ImportError,ValueError):return default,'detector_unavailable'
    except Exception:return default,'detector_error'


def crop_around_center(image,size,center):
    """Aspect crop preserving original pixels, with bounds-safe center."""
    width,height=image.size
    dstw,dsth=size
    src_ratio=width/height;target_ratio=dstw/dsth
    if src_ratio>target_ratio:
        cw=height*target_ratio;ch=height
    else:
        cw=width;ch=width/target_ratio
    x=max(0.,min(width-cw,center[0]*width-cw/2))
    y=max(0.,min(height-ch,center[1]*height-ch/2))
    box=(round(x),round(y),round(x+cw),round(y+ch))
    return image.crop(box).resize(size,Image.Resampling.LANCZOS)


def enhance_image(source, auto=False, angle=0, kind='photo', deskew=False, photo_straighten=False, brightness=1.0, contrast=1.0, sharpness=1.0, background='original', background_color='#ffffff', background_provider='auto', ai_key=None):
    with Image.open(source) as raw:
        im = ImageOps.exif_transpose(raw).convert('RGB')
    photo_angle=0.0
    photo_status='disabled'
    if kind=='photo' and photo_straighten:
        photo_angle,photo_status=estimate_photo_tilt(im)
    # Rotate the whole photograph, never move facial features independently.
    background_method='original'
    if background!='original':
        colors={'white':(255,255,255),'studio':(49,90,174),'sky':(124,202,248),'red':(205,32,56)}
        if background=='custom':
            import re
            if not re.fullmatch('#[A-Fa-f0-9]{6}',str(background_color)):
                raise ValueError('কাস্টম ব্যাকগ্রাউন্ডের রং সঠিক নয়')
            colors['custom']=tuple(bytes.fromhex(background_color[1:]))
        if background not in colors or kind!='photo':raise ValueError('এই ব্যাকগ্রাউন্ড অপশন উপলব্ধ নয়')
        if background_provider not in ('auto', 'bgclear'):
            raise ValueError('পুরোনো Offline/OpenCV ব্যাকগ্রাউন্ড কাটিং বন্ধ। BG Clear Online AI ব্যবহার করুন।')
        if not ai_key:
            raise ValueError('ব্যাকগ্রাউন্ড পরিবর্তন করতে অ্যাডমিন প্যানেলে BG Clear API key বসান। Offline কাটিং বন্ধ রাখা হয়েছে যাতে চুল কেটে না যায়।')
        # No GrabCut/low-quality fallback: failures must be visible to the operator.
        fg=remove_background(im, ai_key)
        background_method='bgclear_online_ai_preview'
        bg=Image.new('RGBA',fg.size,colors[background]+(255,))
        bg.alpha_composite(fg)
        im=bg.convert('RGB')
    # Scanned forms: detect modest global skew from printed lines/text, not body position.
    estimate=0.0
    if deskew and kind=='document':
        try:
            import cv2, numpy as np
            g=cv2.cvtColor(np.array(im), cv2.COLOR_RGB2GRAY)
            scale=min(1,1300/max(g.shape))
            if scale<1:g=cv2.resize(g,None,fx=scale,fy=scale)
            binary=cv2.threshold(g,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)[1]
            coords=np.column_stack(np.where(binary>0))
            if len(coords)>100:
                rawangle=cv2.minAreaRect(coords.astype('float32'))[-1]
                # Avoid aggressive rotation of unsuitable images.
                candidate = -(90+rawangle) if rawangle < -45 else -rawangle
                if abs(candidate)<=8:estimate=float(candidate)
        except ImportError:pass
        except Exception:pass
    correction=float(angle)+estimate+photo_angle
    if abs(correction)>30:raise ValueError('ঘোরানোর কোণ সর্বোচ্চ ±৩০°')
    if correction:im=im.rotate(correction,resample=Image.Resampling.BICUBIC,expand=True,fillcolor='white')
    if auto:
        # Gentle, non-generative adjustments. Facial features/geometry are untouched.
        im=ImageOps.autocontrast(im,cutoff=0.5,preserve_tone=True)
        if kind=='photo':
            im=ImageEnhance.Color(im).enhance(1.05)
            im=ImageEnhance.Contrast(im).enhance(1.04)
            im=im.filter(ImageFilter.UnsharpMask(radius=1.1,percent=85,threshold=3))
        else:
            im=ImageEnhance.Contrast(im).enhance(1.15)
            im=im.filter(ImageFilter.UnsharpMask(radius=1,percent=100,threshold=3))
    for value in (brightness,contrast,sharpness):
        if not .5<=float(value)<=1.8:raise ValueError('এনহ্যান্স মান 0.5–1.8 হতে হবে')
    if float(brightness)!=1:im=ImageEnhance.Brightness(im).enhance(float(brightness))
    if float(contrast)!=1:im=ImageEnhance.Contrast(im).enhance(float(contrast))
    if float(sharpness)!=1:im=ImageEnhance.Sharpness(im).enhance(float(sharpness))
    # Avoid extreme images causing excessive PDF sizes.
    im.thumbnail((4500,4500), Image.Resampling.LANCZOS)
    im.info['background_method']=background_method
    im.info['photo_alignment_status']=photo_status
    im.info['photo_angle_deg']=photo_angle
    return im

def make_photo_layout(source, out, preset='passport', count=4, photo_w=35, photo_h=45, photo_dpi=None,
                      paper='A4', paper_w=210, paper_h=297, paper_orientation='portrait',
                      image_orientation='portrait', auto=False, photo_straighten=False, angle=0, brightness=1,
                      contrast=1, sharpness=1, background='original', background_color='#ffffff', margin=5, gap=2,
                      stamp_columns=0, stamp_gap=2, stamp_margin=5, passport_row_layout=True,
                      background_provider='auto', ai_key=None):
    count=int(count)
    if not 1<=count<=60:raise ValueError('ছবির সংখ্যা ১–৬০ হতে হবে')
    w,h=photo_size(preset,photo_w,photo_h)
    if image_orientation=='landscape':w,h=max(w,h),min(w,h)
    elif image_orientation=='portrait':w,h=min(w,h),max(w,h)
    else:raise ValueError('ছবির দিক সঠিক নয়')
    page_w,page_h=paper_dimensions(paper,paper_orientation,paper_w,paper_h)
    if preset=='stamp':
        margin,gap=float(stamp_margin),float(stamp_gap)
    else:
        margin,gap=float(margin),float(gap)
    if not 2<=margin<=20 or not 0<=gap<=15:raise ValueError('মার্জিন/ফাঁক সঠিক নয়')
    cols=math.floor((page_w-2*margin+gap)/(w+gap)+1e-8)
    rows=math.floor((page_h-2*margin+gap)/(h+gap)+1e-8)
    # Horizontal arrangement means upright passport photos fill the row.
    # It must not rotate faces or turn the paper into landscape orientation.
    if preset=='passport' and passport_row_layout is False:
        cols=1
    if preset=='stamp':
        requested_cols=int(stamp_columns)
        if not 0<=requested_cols<=10:raise ValueError('স্ট্যাম্পের কলাম ০ (Auto) অথবা ১–১০ দিন')
        if requested_cols:
            if requested_cols>cols:raise ValueError('এই পেজে স্ট্যাম্পের নির্ধারিত কলাম বসছে না; কলাম বা ফাঁক কমান')
            cols=requested_cols
    if cols*rows<1:raise ValueError('এই কাগজে ছবিটি বসছে না; মাপ বা মার্জিন কমান')
    img=enhance_image(source,auto=bool(auto),photo_straighten=bool(photo_straighten),angle=angle,brightness=brightness,contrast=contrast,sharpness=sharpness,background=background,background_color=background_color,background_provider=background_provider,ai_key=ai_key)
    alignment_status=img.info.get('photo_alignment_status','disabled')
    background_method=img.info.get('background_method','original')
    photo_angle=img.info.get('photo_angle_deg',0.0)
    # Crop to passport proportions, but preserve the original face structure.
    if photo_dpi is None:photo_dpi=150 if preset=='stamp' else 300
    photo_dpi=int(photo_dpi)
    if photo_dpi not in (150,300):raise ValueError('ছবির DPI 150 অথবা 300 হতে হবে')
    dest_w=max(1,round(w/25.4*photo_dpi)); dest_h=max(1,round(h/25.4*photo_dpi))
    crop_center,crop_status=smart_face_crop_center(img,w/h)
    tile=crop_around_center(img,(dest_w,dest_h),crop_center)
    c=Canvas(str(out),pagesize=(page_w*MM_PT,page_h*MM_PT),pageCompression=1)
    pages=math.ceil(count/(cols*rows))
    for n in range(count):
        if n and n%(cols*rows)==0:c.showPage()
        pos=n%(cols*rows); col=pos%cols; row=pos//cols
        x=(margin+col*(w+gap))*MM_PT
        y=(page_h-margin-h-row*(h+gap))*MM_PT
        c.drawImage(ImageReader(tile),x,y,w*MM_PT,h*MM_PT)
    c.showPage();c.save()
    return {'pages':pages,'per_page':cols*rows,'copies':count,'paper_mm':[page_w,page_h],'photo_mm':[w,h],'photo_dpi':photo_dpi,'photo_pixels':[dest_w,dest_h],
            'photo_alignment_status':alignment_status,'photo_angle_deg':photo_angle,'background_method':background_method,'smart_crop_status':crop_status}

def make_document_image_pdf(source,out,paper='A4',paper_orientation='portrait',paper_w=210,paper_h=297,
                            auto=False,deskew=False,angle=0,brightness=1,contrast=1,sharpness=1,fit='contain'):
    w,h=paper_dimensions(paper,paper_orientation,paper_w,paper_h)
    image=enhance_image(source,auto=auto,deskew=deskew,kind='document',angle=angle,brightness=brightness,contrast=contrast,sharpness=sharpness)
    if fit not in {'contain','cover'}:raise ValueError('ফিটের অপশন সঠিক নয়')
    avail_w,avail_h=w-10,h-10
    if fit=='cover':image=ImageOps.fit(image,(max(1,int(avail_w*6)),max(1,int(avail_h*6))),Image.Resampling.LANCZOS)
    ir=image.width/image.height; boxr=avail_w/avail_h
    if ir>boxr:draw_w=avail_w;draw_h=draw_w/ir
    else:draw_h=avail_h;draw_w=draw_h*ir
    c=Canvas(str(out),pagesize=(w*MM_PT,h*MM_PT));c.drawImage(ImageReader(image),(w-draw_w)/2*MM_PT,(h-draw_h)/2*MM_PT,width=draw_w*MM_PT,height=draw_h*MM_PT)
    c.showPage();c.save()
    return {'pages':1,'paper_mm':[w,h]}

def make_selected_pdf(source,out,pages='all',paper='A4',paper_orientation='portrait',paper_w=210,paper_h=297,rotate=0):
    with fitz.open(str(source)) as doc:
        inds=parse_pages(pages,len(doc))
        # Restrict pages and bound complexity on customer printers.
        if len(inds)>50:raise ValueError('একবারে সর্বোচ্চ ৫০ পৃষ্ঠা নির্বাচন করুন')
        w,h=paper_dimensions(paper,paper_orientation,paper_w,paper_h)
        target=fitz.open()
        try:
            for idx in inds:
                src=doc[idx]; dest=target.new_page(width=w*MM_PT,height=h*MM_PT)
                if int(rotate) not in (0,90,180,270):raise ValueError('রোটেশন 0/90/180/270 হতে হবে')
                bound=fitz.Rect(5*MM_PT,5*MM_PT,(w-5)*MM_PT,(h-5)*MM_PT)
                dest.show_pdf_page(bound,doc,idx,keep_proportion=True,rotate=int(rotate))
            target.save(str(out),garbage=3,deflate=True)
        finally:target.close()
    return {'pages':len(inds),'paper_mm':[w,h]}
