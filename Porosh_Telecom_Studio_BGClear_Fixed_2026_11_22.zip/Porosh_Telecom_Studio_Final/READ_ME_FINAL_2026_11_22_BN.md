# FINAL RELEASE — API ONLY
**আগে এই ফাইলটি পড়ুন।** পূর্বের README/UPDATE-এ Offline OpenCV fallback লেখা থাকলে সেটি এখন আর প্রযোজ্য নয়।

ফাইনাল সেটআপ ও সীমাবদ্ধতা: `ONLINE_AI_SETUP_BN.md`।

- Photoroom Sandbox key: পরীক্ষা ও ডেমো, Watermark থাকবে; বাণিজ্যিক কাজের জন্য নয়।
- Photoroom Live key: নিয়মিত কাজের জন্য, প্রয়োজনীয় ক্রেডিট ও চার্জ থাকতে পারে।
- ব্যাকগ্রাউন্ড বদলাতে **AI key + দোকানের PC-তে admin login** লাগবে। Key না থাকলে Original ব্যাকগ্রাউন্ডের পাসপোর্ট/স্ট্যাম্প/প্রিন্ট আগের মতো চলবে।
- ল্যান্ডস্কেপ ফটো টাইলের জন্য পুরো পেজ ঘুরবে না। Auto Straighten Before/After Preview রাখা হয়েছে।
- Windows ড্রাইভার, প্রকৃত API এবং প্রিন্টার লাইভ যাচাই জরুরি।
