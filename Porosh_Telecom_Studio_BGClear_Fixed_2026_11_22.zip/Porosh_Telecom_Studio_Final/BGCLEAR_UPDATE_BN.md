# BG Clear Online AI আপডেট — ২২ নভেম্বর ২০২৬

- পূর্বের PDF Tools, Scanner, Multi-Scan, প্রিন্ট এবং ছবির DPI/সাইজ অপরিবর্তিত।
- অনলাইন AI: BG Clear। `/admin`-এ নিজের API key দিন। পুরোনো Photoroom key ব্যবহার হবে না।
- এই সংস্করণ শুধু BG Clear-এর `size=preview` (সর্বোচ্চ ৮০০ পিক্সেল), `store=false`, `crop=false` ব্যবহার করে। কোনো ক্রেডিট খরচের Full mode স্বয়ংক্রিয় চালু হবে না।
- ছবির প্রিন্ট-মাপ ও DPI আগের মতো থাকে; তবে ৮০০ পিক্সেল থেকে upscale করা হলে আসল detail বাড়ে না।
- ছবি বাঁকা হওয়া ঠেকাতে Auto Straighten ডিফল্ট বন্ধ, ম্যানুয়াল Angle ০°। দরকার হলে নিজে চালু করুন।
- নতুন ভার্সন আলাদা ফোল্ডারে Extract করে `START_WINDOWS.bat` চালান। প্রিন্টের আগে প্রিভিউ দেখুন।
- BG Clear-এর আসল নেটওয়ার্ক API সফল হয়েছে বলে দাবি করা হচ্ছে না: ব্যবহারকারীর key দিয়ে দোকানের কম্পিউটারে পরীক্ষা করতে হবে।

- API error handling উন্নত: BG Clear-এর JSON error code থেকে unsupported image format ও invalid request আলাদা করে বাংলায় দেখায়।
- API multipart request-এ optional `type` hint বাদ; BG Clear নিজে subject detect করে। `format=png` স্পষ্টভাবে পাঠানো হয়।
- BG Clear API বাস্তব নেটওয়ার্কে ব্যবহারকারীর key দিয়ে এখানে পরীক্ষা করা হয়নি; Windows PC-তে একবার Preview চালিয়ে যাচাই করতে হবে।
