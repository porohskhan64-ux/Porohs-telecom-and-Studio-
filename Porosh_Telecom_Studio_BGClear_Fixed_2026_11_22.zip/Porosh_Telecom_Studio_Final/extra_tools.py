"""Small, offline ID/PDF/document utilities; never synthesizes document text."""
from pathlib import Path
import os
import tempfile
import io
import fitz
from PIL import Image, ImageEnhance, ImageFilter, ImageOps
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.utils import ImageReader
from engine import MM_PT, IMAGE_EXT, make_document_image_pdf, parse_pages


def _card_image(path, auto_crop=True):
    with Image.open(path) as f:
        im=ImageOps.exif_transpose(f).convert('RGB')
    im.thumbnail((2300, 2300))
    if auto_crop:
        # Reject ambiguous contours rather than cropping away real ID content.
        try:
            import numpy as np, cv2
            source=np.asarray(im); h,w=source.shape[:2]
            small=cv2.resize(source,(max(1,int(w*min(1,1100/w))),max(1,int(h*min(1,1100/w)))))
            gray=cv2.cvtColor(small,cv2.COLOR_RGB2GRAY)
            edge=cv2.Canny(cv2.GaussianBlur(gray,(5,5),0),35,110)
            contours,_=cv2.findContours(edge,cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
            sh,sw=small.shape[:2]
            contours=sorted(contours,key=cv2.contourArea,reverse=True)[:15]
            matches=[]
            for contour in contours:
                length=cv2.arcLength(contour,True)
                quad=cv2.approxPolyDP(contour,0.025*length,True)
                if len(quad)!=4:continue
                pts=quad.reshape(4,2).astype('float32')
                rect=cv2.minAreaRect(pts); a,b=rect[1]
                if not a or not b:continue
                ratio=max(a,b)/min(a,b)
                area=cv2.contourArea(pts)/(sw*sh)
                if 1.40<ratio<1.85 and 0.25<area<0.95:
                    matches.append((area,pts))
            if matches:
                pts=max(matches,key=lambda x:x[0])[1]
                sums=pts.sum(axis=1); diffs=np.diff(pts,axis=1).flatten()
                tl=pts[sums.argmin()]; br=pts[sums.argmax()]
                tr=pts[diffs.argmin()]; bl=pts[diffs.argmax()]
                ordered=np.array([tl,tr,br,bl],dtype='float32')
                # Preserve physical card aspect ratio; do not enhance/reconstruct text.
                scale=max(w/sw,h/sh)
                width=min(2200,max(600,int(85.6*12)))
                height=int(width*54/85.6)
                mat=cv2.getPerspectiveTransform(ordered*scale,np.array([[0,0],[width-1,0],[width-1,height-1],[0,height-1]],dtype='float32'))
                im=Image.fromarray(cv2.warpPerspective(source,mat,(width,height),borderMode=cv2.BORDER_REPLICATE))
        except (ImportError,ValueError,cv2.error if 'cv2' in locals() else ValueError):
            pass
    return im


def make_nid_sheet(front, back, out, auto_crop=True, enhance=False):
    """Two 85.6 × 54 mm cards centered on portrait A4."""
    a=_card_image(front,auto_crop); b=_card_image(back,auto_crop)
    if enhance:
        a=ImageOps.autocontrast(a,cutoff=.3); b=ImageOps.autocontrast(b,cutoff=.3)
    doc=Canvas(str(out),pagesize=(210*MM_PT,297*MM_PT))
    w,h=85.6,54; x=(210-w)/2
    for im,y in ((a,297-28-h),(b,297-28-h-14-h)):
        # Avoid trimming any unreadable-looking corner of an ID.
        im=ImageOps.contain(im,(max(1,int(85.6*10)),max(1,int(54*10))),Image.Resampling.LANCZOS)
        draw_w=w*im.width/(85.6*10);draw_h=h*im.height/(54*10)
        doc.setStrokeColorRGB(.78,.84,.92)
        doc.rect(x*MM_PT,y*MM_PT,w*MM_PT,h*MM_PT,stroke=1,fill=0)
        doc.drawImage(ImageReader(im),(x+(w-draw_w)/2)*MM_PT,
            (y+(h-draw_h)/2)*MM_PT,width=draw_w*MM_PT,height=draw_h*MM_PT)
    doc.showPage();doc.save()
    return {'pages':1,'paper_mm':[210,297],'card_mm':[85.6,54],'method':'conservative detection'}


def pdf_action(paths, out, action, pages='all', rotation=90):
    """Safely transform PDF pages without rasterizing text or photos.

    split: extract selected pages into ONE PDF, reorder: selected pages in
    specified order, delete: remove selected pages, rotate: turn selected
    pages in place. PDF optimization never downscales scanned documents.
    """
    actions = {'merge', 'split', 'compress', 'rotate', 'reorder', 'delete', 'odd', 'even'}
    if action not in actions:
        raise ValueError('PDF কাজটি সঠিক নয়')
    if action == 'merge':
        if not 2 <= len(paths) <= 10:
            raise ValueError('Merge করতে ২–১০টি PDF দিন')
    elif len(paths) != 1:
        raise ValueError('এই কাজের জন্য একটি PDF দিন')
    if not isinstance(pages, str) or len(pages) > 400:
        raise ValueError('পৃষ্ঠা রেঞ্জ সঠিক নয় (যেমন 1,3,5-7)')
    try:
        rotation = int(rotation)
    except (ValueError, TypeError):
        raise ValueError('পৃষ্ঠার ঘূর্ণন ৯০, ১৮০ বা ২৭০ ডিগ্রি দিন') from None
    if action == 'rotate' and rotation not in (90,180,270):
        raise ValueError('পৃষ্ঠার ঘূর্ণন ৯০, ১৮০ বা ২৭০ ডিগ্রি দিন')

    # Input files are already ownership-checked by the HTTP route.
    # Refuse empty/encrypted/oversized files before creating an output.
    source_pages = 0
    for source_path in paths:
        try:
            with fitz.open(str(source_path)) as source:
                if source.needs_pass:
                    raise ValueError('পাসওয়ার্ড-সুরক্ষিত PDF আগে আনলক করুন')
                if not source.is_pdf or source.page_count < 1:
                    raise ValueError('সঠিক PDF-এ অন্তত একটি পৃষ্ঠা থাকতে হবে')
                source_pages += source.page_count
        except (fitz.FileDataError, fitz.EmptyFileError):
            raise ValueError('PDF ফাইলটি ক্ষতিগ্রস্ত বা অসমর্থিত') from None
    if source_pages > 120:
        raise ValueError('একসঙ্গে সর্বোচ্চ ১২০ পৃষ্ঠা প্রসেস করা যাবে')

    output = Path(out)
    output.parent.mkdir(parents=True, exist_ok=True)
    # Save in the same directory, then atomically replace the public export.
    fd, temp_name = tempfile.mkstemp(prefix='pdf-work-',suffix='.pdf',dir=output.parent)
    os.close(fd)
    tmp = Path(temp_name)
    try:
        with fitz.open() as result:
            if action == 'compress':
                with fitz.open(str(paths[0])) as original:
                    # Native lossless compression preserves searchable text,
                    # vector graphics, document metadata, page size & quality.
                    original.save(str(tmp),garbage=4,deflate=True,
                                  deflate_images=True,deflate_fonts=True,
                                  use_objstms=1)
                    count=original.page_count
                # Optimization can increase size on already-compressed files.
                # Return unchanged source when it is already more compact.
                if tmp.stat().st_size >= Path(paths[0]).stat().st_size:
                    import shutil
                    shutil.copyfile(paths[0],tmp)
            elif action == 'merge':
                for path in paths:
                    with fitz.open(str(path)) as source:
                        result.insert_pdf(source,links=True,annots=True)
                count=result.page_count
                result.save(str(tmp),garbage=4,deflate=True,use_objstms=1)
            else:
                with fitz.open(str(paths[0])) as source:
                    n=source.page_count
                    selected=parse_pages(pages,n) if pages.strip().lower()!='all' else list(range(n))
                    if action in ('odd','even'):
                        # PDF page numbers begin with 1, while fitz indices begin with 0.
                        selected=[i for i in selected if ((i+1)%2 == (1 if action=='odd' else 0))]
                        if not selected:raise ValueError('এই রেঞ্জে কোনো '+('বিজোড়' if action=='odd' else 'জোড়')+' পৃষ্ঠা নেই')
                    selected_set=set(selected)
                    if action == 'delete':
                        indices=[i for i in range(n) if i not in selected_set]
                        if not indices:
                            raise ValueError('সব পৃষ্ঠা বাদ দেওয়া যাবে না; অন্তত একটি পৃষ্ঠা রাখুন')
                    elif action in ('split','reorder','odd','even'):
                        indices=selected
                    else:
                        indices=list(range(n))
                    if action == 'rotate':
                        # Keep untouched pages and their original dimensions.
                        result.insert_pdf(source,links=True,annots=True)
                        for index in selected:
                            page=result[index]
                            page.set_rotation((page.rotation+rotation)%360)
                    else:
                        # insert_pdf accepts arbitrary page order without
                        # rasterizing text; preserve selected original order.
                        for i in indices:
                            result.insert_pdf(source,from_page=i,to_page=i,
                                              links=True,annots=True)
                    count=result.page_count
                    result.save(str(tmp),garbage=4,deflate=True,use_objstms=1)
        # Validate before publishing; never expose a partial PDF to a user.
        with fitz.open(str(tmp)) as check:
            if check.needs_pass or check.page_count != count or count < 1:
                raise ValueError('তৈরি করা PDF যাচাই করা যায়নি')
            first=check[0].rect
            size_mm=[round(first.width/MM_PT,2),round(first.height/MM_PT,2)]
        os.replace(tmp,output)
    finally:
        tmp.unlink(missing_ok=True)

    in_bytes=sum(Path(path).stat().st_size for path in paths)
    out_bytes=output.stat().st_size
    size=lambda b:round(b/1048576,2)
    messages={
        'merge':'একাধিক PDF নির্বাচিত ক্রমে যুক্ত হয়েছে।',
        'split':'নির্বাচিত পৃষ্ঠাগুলো একটি নতুন PDF-এ রাখা হয়েছে (আলাদা ফাইল নয়)।',
        'compress':'Lossless Optimize: ছবি/লেখার মান কমানো হয়নি; ফাইল আগে থেকেই ছোট হলে অপরিবর্তিত রাখা হয়েছে।',
        'rotate':f'নির্বাচিত পৃষ্ঠা {rotation}° ঘোরানো হয়েছে; অন্য পৃষ্ঠা অপরিবর্তিত।',
        'reorder':'দেওয়া ক্রমে পৃষ্ঠা সাজানো হয়েছে; রেঞ্জে না থাকা পৃষ্ঠা রাখা হয়নি।',
        'delete':'নির্বাচিত পৃষ্ঠা বাদ দিয়ে বাকি পৃষ্ঠাগুলো রাখা হয়েছে।',
        'odd':'শুধু বিজোড় (১, ৩, ৫ ...) পৃষ্ঠা প্রিন্টের জন্য প্রস্তুত। মূল PDF অপরিবর্তিত।',
        'even':'শুধু জোড় (২, ৪, ৬ ...) পৃষ্ঠা প্রিন্টের জন্য প্রস্তুত। মূল PDF অপরিবর্তিত।',
    }
    return {'pages':count,'action':action,'paper_mm':size_mm,
            'source_pages':source_pages,'input_mb':size(in_bytes),
            'output_mb':size(out_bytes),'saved_percent':round(max(0,1-out_bytes/max(1,in_bytes))*100,1),
            'note':messages[action]}


def camera_scan(source,out,mode='color'):
    if mode not in ('color','bw'):raise ValueError('স্ক্যান মোড সঠিক নয়')
    im=_card_image(source,auto_crop=True)
    if mode=='bw':
        im=ImageOps.grayscale(im)
        im=ImageOps.autocontrast(im,cutoff=.5)
        im=im.convert('RGB')
    else:im=ImageOps.autocontrast(im,cutoff=.3)
    im=im.filter(ImageFilter.UnsharpMask(radius=1.0,percent=65,threshold=3))
    im.save(out,format='JPEG',quality=90,optimize=True)
    return {'width':im.width,'height':im.height}


def scanned_image_to_pdf(source, out, rect=None, paper='A4', orientation='portrait',
                         custom_w=210, custom_h=297, fit='contain', mode='color'):
    """Crop source pixels without overwriting original, then compose print-ready PDF.

    Rect is [left, top, width, height] normalized to 0..1 of EXIF-corrected image;
    PDF output has the exact requested physical page size in millimeters.
    """
    from engine import paper_dimensions
    import math
    if mode not in ('color','bw'):raise ValueError('স্ক্যানের রং সঠিক নয়')
    if fit not in ('contain','cover'):raise ValueError('স্ক্যানের ফিট অপশন সঠিক নয়')
    if paper not in ('A4','A5','A6','Letter','Legal','custom','ID'):
        raise ValueError('স্ক্যানের কাগজের মাপ সঠিক নয়')
    if paper=='ID':
        wmm,hmm=(85.6,54.0) if orientation=='landscape' else (54.0,85.6)
    else:
        wmm,hmm=paper_dimensions(paper,orientation,custom_w,custom_h)
    if wmm < 20 or hmm < 20:raise ValueError('কাগজের সাইজ খুব ছোট')
    with Image.open(source) as original:
        original.verify()
    with Image.open(source) as original:
        im=ImageOps.exif_transpose(original).convert('RGB')
    if im.width*im.height>45_000_000:raise ValueError('স্ক্যান ছবির রেজোলিউশন খুব বেশি')
    if rect is None: rect=[0,0,1,1]
    if not isinstance(rect,(list,tuple)) or len(rect)!=4:
        raise ValueError('ক্রপের নির্বাচন সঠিক নয়')
    try:
        x,y,w,h=map(float,rect)
    except (ValueError,TypeError):
        raise ValueError('ক্রপের মাপ সঠিক নয়') from None
    if not all(math.isfinite(i) for i in (x,y,w,h)):
        raise ValueError('ক্রপের মাপ সঠিক নয়')
    if x<0 or y<0 or w<=0 or h<=0 or x+w>1.00001 or y+h>1.00001:
        raise ValueError('ক্রপ ছবির বাইরে যেতে পারে না')
    left=max(0,min(im.width-1,round(x*im.width)))
    top=max(0,min(im.height-1,round(y*im.height)))
    right=min(im.width,max(left+1,round((x+w)*im.width)))
    bottom=min(im.height,max(top+1,round((y+h)*im.height)))
    if right-left<16 or bottom-top<16:raise ValueError('কমপক্ষে ১৬ পিক্সেল এলাকা ক্রপ করুন')
    im=im.crop((left,top,right,bottom))
    if mode=='bw':
        im=ImageOps.autocontrast(ImageOps.grayscale(im),cutoff=.25).convert('RGB')
    else:
        im=ImageOps.autocontrast(im,cutoff=.2)
    # PDF is deliberately vector-based canvas with the original scan embedded,
    # not flattened to a low-quality fixed resolution A4 bitmap.
    margin=0 if paper=='ID' else 5
    availw,availh=wmm-2*margin,hmm-2*margin
    targetr=availw/availh
    if fit=='cover':
        # Explicit opt-in for filling the page, may trim edge pixels.
        currentr=im.width/im.height
        if currentr>targetr:
            nw=max(1,round(im.height*targetr));l=(im.width-nw)//2
            im=im.crop((l,0,l+nw,im.height))
        else:
            nh=max(1,round(im.width/targetr));t=(im.height-nh)//2
            im=im.crop((0,t,im.width,t+nh))
    scale=min(availw/im.width,availh/im.height)
    dw,dh=im.width*scale,im.height*scale
    result=Path(out)
    result.parent.mkdir(parents=True,exist_ok=True)
    canvas=Canvas(str(result),pagesize=(wmm*MM_PT,hmm*MM_PT))
    canvas.drawImage(ImageReader(im),(wmm-dw)/2*MM_PT,(hmm-dh)/2*MM_PT,width=dw*MM_PT,height=dh*MM_PT)
    canvas.showPage();canvas.save()
    return {'pages':1,'paper_mm':[round(wmm,2),round(hmm,2)],
            'crop_pixels':[left,top,right,bottom],
            'cropped_pixels':[right-left,bottom-top],
            'note':'ক্রপ নির্বাচন ও কাগজের মাপ অনুযায়ী প্রিন্ট-প্রস্তুত PDF। মূল স্ক্যান অপরিবর্তিত।'}


def scan_batch_to_pdf(items, out, paper='A4', orientation='portrait',
                      custom_w=210, custom_h=297, fit='contain', mode='color',
                      layout='one_page', columns=0):
    """Render distinct manual crops from 1–12 images into a single physical-sized PDF.

    Each item is (existing image file path, normalized rectangle). Sources are
    read-only; the HTTP caller MUST validate per-session ownership of every path.
    """
    import math
    from engine import paper_dimensions
    if not isinstance(items, (list, tuple)) or not 1 <= len(items) <= 12:
        raise ValueError('একসঙ্গে ১–১২টি স্ক্যান যোগ করুন')
    if fit not in ('contain', 'cover') or mode not in ('color', 'bw'):
        raise ValueError('স্ক্যানের ফিট অথবা রং সঠিক নয়')
    if layout not in ('one_page', 'separate_pages'):
        raise ValueError('পাতায় সাজানোর পদ্ধতি সঠিক নয়')
    if paper not in ('A4','A5','A6','Letter','Legal','custom','ID'):
        raise ValueError('কাগজের সাইজ সঠিক নয়')
    if paper == 'ID':
        if orientation not in ('portrait','landscape'):
            raise ValueError('পেজের দিক সঠিক নয়')
        pw,ph=(85.6,54) if orientation=='landscape' else (54,85.6)
    else:
        pw,ph=paper_dimensions(paper,orientation,custom_w,custom_h)
    if pw < 20 or ph < 20:raise ValueError('কাগজের সাইজ খুব ছোট')
    try:columns=int(columns)
    except (ValueError, TypeError):raise ValueError('কলামের সংখ্যা সঠিক নয়') from None
    if columns not in (0,1,2,3,4):raise ValueError('কলাম ১–৪ বা অটো হতে হবে')

    prepared=[]
    for path, rect in items:
        with Image.open(path) as raw:
            raw.verify()
        with Image.open(path) as raw:
            im=ImageOps.exif_transpose(raw).convert('RGB')
        if im.width*im.height > 45_000_000:
            raise ValueError('স্ক্যান ছবির রেজোলিউশন খুব বেশি')
        if not isinstance(rect,(list,tuple)) or len(rect)!=4:
            raise ValueError('প্রতিটি ছবির আলাদা ক্রপ সঠিকভাবে নির্বাচন করুন')
        try:x,y,w,h=map(float,rect)
        except (ValueError,TypeError):raise ValueError('ক্রপ মাপ সঠিক নয়') from None
        if not all(map(math.isfinite,(x,y,w,h))) or x<0 or y<0 or w<=0 or h<=0 or x+w>1.00001 or y+h>1.00001:
            raise ValueError('ক্রপ ছবির বাইরে যেতে পারে না')
        left=max(0,min(im.width-1,round(x*im.width)))
        top=max(0,min(im.height-1,round(y*im.height)))
        right=min(im.width,max(left+1,round((x+w)*im.width)))
        bottom=min(im.height,max(top+1,round((y+h)*im.height)))
        if right-left<16 or bottom-top<16:
            raise ValueError('প্রতিটি ক্রপে কমপক্ষে ১৬ পিক্সেল নির্বাচন করুন')
        im=im.crop((left,top,right,bottom))
        # Cap in-memory images; preserving sufficient pixels for print tiles.
        im.thumbnail((2800,3600) if len(items)==1 else (2000,2600),Image.Resampling.LANCZOS)
        im=ImageOps.autocontrast(ImageOps.grayscale(im),cutoff=.25).convert('RGB') if mode=='bw' else ImageOps.autocontrast(im,cutoff=.2)
        prepared.append(im)

    page_margin=0 if paper=='ID' else 5
    gap=0 if paper=='ID' else 3
    availw,availh=pw-2*page_margin,ph-2*page_margin
    if availw<=0 or availh<=0:raise ValueError('কাগজের মাপ ছোট')
    # Auto chooses a grid maximizing visible image area, respecting order and
    # avoiding unnecessary tiny tiles for long portrait scans.
    n=len(prepared)
    if layout=='separate_pages':cols=1
    elif columns:cols=columns
    else:
        def score(cols):
            rows=math.ceil(n/cols)
            cw=(availw-(cols-1)*gap)/cols
            ch=(availh-(rows-1)*gap)/rows
            if cw<=0 or ch<=0:return -1
            visible=sum(min(cw/im.width,ch/im.height)**2 * im.width*im.height for im in prepared)
            return visible
        cols=max(range(1,min(n,4)+1), key=score)
    cols=min(cols,n)
    rows=1 if layout=='separate_pages' else math.ceil(n/cols)
    cw=(availw-(cols-1)*gap)/cols
    ch=(availh-(rows-1)*gap)/rows
    if cw<=0 or ch<=0:raise ValueError('এক পাতায় এতগুলো স্ক্যান রাখা যাচ্ছে না; বড় কাগজ বা কম কলাম নিন')

    output=Path(out);output.parent.mkdir(parents=True,exist_ok=True)
    doc=Canvas(str(output),pagesize=(pw*MM_PT,ph*MM_PT))
    for i,im in enumerate(prepared):
        if layout=='separate_pages':
            col=row=0
        else:
            col=i%cols;row=i//cols
        x=page_margin+col*(cw+gap)
        y=ph-page_margin-(row+1)*ch-row*gap
        if fit=='cover':
            target_ratio=cw/ch;image_ratio=im.width/im.height
            if image_ratio>target_ratio:
                neww=max(1,round(im.height*target_ratio));left=(im.width-neww)//2
                im=im.crop((left,0,left+neww,im.height))
            else:
                newh=max(1,round(im.width/target_ratio));top=(im.height-newh)//2
                im=im.crop((0,top,im.width,top+newh))
        scale=min(cw/im.width,ch/im.height)
        dw,dh=im.width*scale,im.height*scale
        doc.drawImage(ImageReader(im),
                      (x+(cw-dw)/2)*MM_PT,(y+(ch-dh)/2)*MM_PT,
                      width=dw*MM_PT,height=dh*MM_PT)
        if layout=='separate_pages':doc.showPage()
    if layout=='one_page':doc.showPage()
    doc.save()
    return {'pages': n if layout=='separate_pages' else 1,
            'scans':n,'columns':cols,'paper_mm':[round(pw,2),round(ph,2)],
            'note': f'{n}টি আলাদা ক্রপ করা স্ক্যান '+('এক পাতায়' if layout=='one_page' else 'আলাদা পাতায়')+' সাজানো হয়েছে; মূল ছবিগুলো অপরিবর্তিত আছে।'}


def skin_soften(image,strength=0):
    """Non-generative, locally masked face smoothing (optional), geometry unchanged."""
    strength=float(strength)
    if not 0<=strength<=1:raise ValueError('Skin smoothing 0–1 হতে হবে')
    if strength==0:return image
    try:
        import cv2, numpy as np
        source=np.asarray(image.convert('RGB'))
        h,w=source.shape[:2]; scale=min(1,850/max(h,w))
        detect=cv2.resize(source,None,fx=scale,fy=scale) if scale<1 else source
        gray=cv2.cvtColor(detect,cv2.COLOR_RGB2GRAY)
        xml=cv2.data.haarcascades+'haarcascade_frontalface_default.xml'
        cascade=cv2.CascadeClassifier(xml)
        if cascade.empty():return image
        faces=cascade.detectMultiScale(gray,scaleFactor=1.12,minNeighbors=5,minSize=(60,60))
        if not len(faces):return image
        # Processing capped to ~2 MP, then blended at original dimensions.
        factor=min(1,1600/max(h,w))
        small=cv2.resize(source,None,fx=factor,fy=factor) if factor<1 else source.copy()
        refined=cv2.bilateralFilter(small,7,35,35)
        mask=np.zeros(small.shape[:2],dtype='float32')
        for x,y,fw,fh in faces[:5]:
            cx=int((x+fw*.5)/scale*factor);cy=int((y+fh*.53)/scale*factor)
            rx=max(1,int(fw*.46/scale*factor));ry=max(1,int(fh*.48/scale*factor))
            cv2.ellipse(mask,(cx,cy),(rx,ry),0,0,360,1,-1)
        mask=cv2.GaussianBlur(mask,(0,0),sigmaX=max(2,16*factor))
        mask=np.clip(mask*strength*.55,0,1)[:,:,None]
        mixed=np.uint8(np.clip(small*(1-mask)+refined*mask,0,255))
        if factor<1:mixed=cv2.resize(mixed,(w,h),interpolation=cv2.INTER_LINEAR)
        return Image.fromarray(mixed,'RGB')
    except (ImportError,ValueError):return image


def batch_photo_sheet(paths,out,preset='passport',copies_each=2):
    """Low-memory A4 grid of multiple input photos with original face geometry."""
    from engine import enhance_image, photo_size
    copies_each=int(copies_each)
    if not 1<=len(paths)<=12 or not 1<=copies_each<=12:
        raise ValueError('১–১২টি ছবি, প্রতিটির কপি ১–১২')
    w,h=photo_size(preset,35,45)
    margin,gap=8,3
    cols=int((210-2*margin+gap)/(w+gap));rows=int((297-2*margin+gap)/(h+gap))
    perpage=cols*rows
    if not perpage:raise ValueError('A4 পেজে ছবি বসছে না')
    canvas=Canvas(str(out),pagesize=(210*MM_PT,297*MM_PT),pageCompression=1)
    index=0
    for path in paths:
        if path.suffix.lower() not in IMAGE_EXT:raise ValueError('Batch-এ শুধু ছবি দিন')
        im=enhance_image(path,auto=True,kind='photo')
        im=ImageOps.fit(im,(max(1,int(w*10)),max(1,int(h*10))),Image.Resampling.LANCZOS,centering=(.5,.35))
        ir=ImageReader(im)
        for _ in range(copies_each):
            if index and index%perpage==0:canvas.showPage()
            pos=index%perpage;col=pos%cols;row=pos//cols
            x=(margin+col*(w+gap))*MM_PT
            y=(297-margin-h-row*(h+gap))*MM_PT
            canvas.drawImage(ir,x,y,width=w*MM_PT,height=h*MM_PT)
            index+=1
    canvas.showPage();canvas.save()
    return {'pages':(index+perpage-1)//perpage,'paper_mm':[210,297],
            'copies':index,'photo_mm':[w,h],'photos':len(paths)}
