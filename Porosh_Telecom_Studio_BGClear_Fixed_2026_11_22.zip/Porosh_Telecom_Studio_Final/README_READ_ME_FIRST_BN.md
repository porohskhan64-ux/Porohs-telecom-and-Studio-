# Porosh Telecom & Studio — Feature-Integrated Test Build (Windows 10 64-bit)

**ফাইলের কাজ:** এটি আগে দেওয়া Python 3.12 প্রজেক্টের উপর ভিত্তি করে নতুন, Mobile-First আপডেট। মূল PC Studio-র পাশাপাশি `/customer` নামে একটি হালকা মোবাইল পেজ যুক্ত হয়েছে। পেইড API বাধ্যতামূলক নয়।

## প্রথমবার চালানো

1. ZIP ফাইলটি Windows 10 64-bit কম্পিউটারে **Extract All** করুন। ZIP-এর ভেতর থেকে সরাসরি চালাবেন না।
2. Python 3.12 (64-bit) ইনস্টল থাকতে হবে। না থাকলে python.org থেকে বিনামূল্যে ইনস্টল করুন।
3. `START_WINDOWS.bat` ডাবল-ক্লিক করুন। প্রথমবার Flask, Pillow, PyMuPDF, ReportLab, OpenCV, pywin32 ইত্যাদি বিনামূল্যে ইনস্টল করতে **ইন্টারনেট লাগবে**। পরের বার অকারণে সব প্যাকেজ আবার ইনস্টল হবে না।
4. দোকানের PC থেকে `http://127.0.0.1:5000` খুলুন। অ্যাডমিন পেজ `http://127.0.0.1:5000/admin`।
5. একই Wi-Fi-র ফোনে QR স্ক্যান করুন; এটি `/customer` পেজ খুলবে। একই LAN-এ PC চালু রাখতে হবে। Windows Firewall-এ Private Network-এ port 5000 অনুমতি লাগতে পারে। **ইন্টারনেটে পোর্ট ফরওয়ার্ড করবেন না।**

## নতুন/উন্নত ফিচার

- **মোবাইল customer portal:** হালকা responsive UI, ফোনের ক্যামেরা থেকে ছবি, ডকুমেন্ট, PDF, NID; ছয়টি পরিষেবা, ছোট JPG PDF-প্রিভিউ, সেশনভিত্তিক ফাইল অ্যাক্সেস।
- **PC photo studio:** পাসপোর্ট/স্ট্যাম্প ফটো PDF, ছবির Batch A4 layout, PC editor Undo/Redo, ডার্ক/লাইট থিম, কাস্টম পেপার, অটো Enhance, conservative auto-straighten, brightness/contrast/sharpness, মূল মুখের গঠন অক্ষুণ্ণ রাখার চেষ্টা।
- **ফ্রি ফটো টুলস:** মৃদু face-area skin softening, OpenCV-এর Fast Offline background cleanup (White, Blue, Sky, Red, Custom)। এটি generative AI নয়; complex hair/background ও skin-retouch-এ ফল নিখুঁত হওয়ার গ্যারান্টি নেই।
- **NID studio:** সামনে/পেছনের ছবি, আত্মবিশ্বাসযোগ্য চারকোণা থাকলে perspective crop, তথ্য না বানিয়ে A4 portrait-এর এক পাতায় **85.6×54 mm**-এর দুই কার্ড।
- **PDF tools:** merge, split/page selection, lossless compress/optimize; PDF/Office এবং image-to-PDF; Office-to-PDF-এর জন্য বিনামূল্যের LibreOffice আলাদাভাবে ইনস্টল থাকতে হবে।
- **Phone Camera Scan:** ছবি থেকে heuristic auto-crop, contrast, scan PDF। ব্রাউজারে `capture` সমর্থন ফোন/ব্রাউজারভেদে বদলাতে পারে।
- **Epson L3110 scanner:** Windows WIA সাপোর্ট থাকলে Python worker-এর মাধ্যমে মোবাইল থেকেই scan request; single-device queue। **Epson Scan 2 ইনস্টল থাকলেই WIA নিশ্চিত নয়**। WIA না পেলে ফোনের camera scan কাজ করবে। ভুল গ্রাহকের কাগজ স্ক্যান না করতে ব্যবহারকারীর সতর্কতা জরুরি।
- **তিন প্রিন্টারের নির্বাচন:** Epson L3110, Epson L130, Canon LBP6030 Windows-এ ইনস্টল থাকলে যে নাম Windows দেখায় সেটিই UI-তে আসবে। নির্বাচিত প্রিন্টারে সরাসরি print-queue submission, স্বয়ংক্রিয় print queue, rate/copy/page limits।
- **Driver quality:** Normal হলে SumatraPDF থাকলে silent print, না থাকলে Windows GDI। Draft/High/Super High-এর জন্য **per-job DEVMODE request** ব্যবহার করা হয়েছে, যা Windows প্রিন্টারের ডিফল্ট সেটিংস বদলায় না। কোনো কোনো Canon/Epson driver এ অনুরোধ না-ও মানতে পারে, বিশেষ করে Super High/private photo-paper modes। A6/Custom paper-এর উচ্চ মানের GDI প্রিন্ট ড্রাইভারের পেপার সেটিংস লাগতে পারে। বাস্তব পরীক্ষা ছাড়া নির্ভরযোগ্যতার দাবি করা যাবে না।
- **Admin:** localhost-only settings, সীমিত-অনুমতির auto print/auto scanner, SQLite print history, পৃষ্ঠা × দরের **আনুমানিক মূল্য** (বাস্তব বিক্রি নয়), backup ZIP; এক গ্রাহকের ফাইল অন্য গ্রাহকের সেশন থেকে খুলতে বাধা। ২৪ ঘণ্টা পর ফাইল পরিষ্কারের worker।

## বাস্তব পরীক্ষার তালিকা — আপনার Windows PC-তে

1. প্রথমে `PRINT_SCAN_DIAGNOSTIC.bat` চালিয়ে তিন প্রিন্টারের সঠিক নাম এবং Windows WIA scanner তালিকা দেখুন।
2. Canon LBP6030 থেকে একটি সাধারণ 1-page A4 BW PDF পাঠিয়ে দেখুন Print Dialog না এসে কাজ queue-তে যায় কি না।
3. Epson L130/L3110 Color, B&W, Draft, High, Super High আলাদা আলাদা টেস্ট করুন। ড্রাইভার-নির্দিষ্ট media/quality UI সবসময় সাধারণ Windows DEVMODE-এ প্রকাশ পায় না।
4. দোকানের Wi-Fi থেকে ফোনে QR খুলুন; ছবি/PDF আপলোড → প্রিভিউ → প্রিন্টের অনুরোধ পাঠান।
5. Epson Scan 2 থাকা সত্ত্বেও `WIA scanners: []` দেখালে WIA-compatible driver বা আলাদা bridge লাগবে। ততক্ষণ phone camera scan ব্যবহার করুন।
6. NID কার্ড PDF প্রিন্ট করার পর ruler দিয়ে **85.6×54 mm** মাপ ঠিক আছে কি না পরীক্ষা করুন; প্রিন্টার scaling 100% হওয়া উচিত।

## পারফরম্যান্স ও গোপনীয়তা

4 GB RAM ও Intel i3-এর জন্য preview 950px সীমিত, ছবি/রেন্ডার সাইজ সীমিত, worker serialized, server-side processing রাখা হয়েছে। খুব বড় PDF, দুর্বল Wi-Fi ও OpenCV background removal ধীর হতে পারে। 100% hang-free বা AI studio-quality নিশ্চিত করা সম্ভব নয়। গ্রাহকের প্রাইভেট ছবি/ID একই নেটওয়ার্কে HTTP-তে যাতায়াত করে, তাই **বিশ্বাসযোগ্য ও বিচ্ছিন্ন দোকানের LAN ব্যবহার করুন**; পাবলিক ইন্টারনেটের উপর এই ডেভেলপমেন্ট সার্ভার প্রকাশ করবেন না।

## পরীক্ষার বর্তমান অবস্থা

- Python syntax, original photo tests, new NID/PDF/phone scan processing tests এবং JavaScript syntax পরীক্ষা হয়েছে।
- এই নির্মাণ পরিবেশে Flask প্যাকেজ পাওয়া যায়নি এবং প্যাকেজ ডাউনলোড বন্ধ ছিল; **HTTP end-to-end পরীক্ষা এখান থেকে করা যায়নি**। Windows driver/WIA/USB প্রিন্ট বাস্তবে পরীক্ষা করা হয়নি।
- এই ZIP তাই feature-integrated **test build**, বাস্তব Windows হার্ডওয়্যার-সনদপ্রাপ্ত release নয়। আপনার প্রিন্ট পরীক্ষায় ভুল পেলে সংশোধন করতে হবে।
