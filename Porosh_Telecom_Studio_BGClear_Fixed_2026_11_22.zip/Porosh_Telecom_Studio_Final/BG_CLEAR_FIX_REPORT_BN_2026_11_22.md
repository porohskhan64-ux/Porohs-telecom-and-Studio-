# BG Clear API সংশোধন প্রতিবেদন — ২২ নভেম্বর ২০২৬

## সংশোধন
1. BG Clear API-এর অফিসিয়াল error JSON পড়ে `unsupported_format` এবং `invalid_request` আলাদা করে দেখানো হয়।
2. `401/403`, `402`, `429`, `503`-এর জন্য নিরাপদ ও স্পষ্ট বাংলা বার্তা রাখা হয়েছে।
3. স্বচ্ছ আউটপুটের জন্য `format=png` স্পষ্টভাবে পাঠানো হয়।
4. অপ্রয়োজনীয় optional `type=person` ফিল্ড বাদ দেওয়া হয়েছে; API-কে subject নিজে শনাক্ত করতে দেওয়া হয়।
5. পুরোনো Photoroom-ভিত্তিক সেটআপ নির্দেশনা BG Clear-এর বর্তমান নির্দেশনায় প্রতিস্থাপন করা হয়েছে।
6. API Key গোপন রাখার বর্তমান নীতি অপরিবর্তিত: key আলাদা `data/bgclear_api.key` ফাইলে থাকে, ZIP-এ যোগ হয় না।

## পরীক্ষার ফল
- BG Clear request, Bearer authentication, free preview fields, transparent PNG, layout integration এবং API error mapping-এর mock-based পরীক্ষা পাস করেছে।
- এই পরিবেশে BG Clear-এ বাস্তব API call করা হয়নি; তাই ব্যবহারকারীর নিজস্ব key দিয়ে Windows PC-তে একটি Preview চালিয়ে বাস্তব সংযোগ নিশ্চিত করতে হবে।
- পূর্ণ test suite-এর কিছু পরীক্ষা এই রানটাইমে প্রয়োজনীয় Flask dependency না থাকায় সংগ্রহ করা যায়নি; একটি বিদ্যমান static assertion-ও প্রজেক্টের বর্তমান template-এর সঙ্গে মেলেনি। এগুলোকে পাস বলে দাবি করা হচ্ছে না।
