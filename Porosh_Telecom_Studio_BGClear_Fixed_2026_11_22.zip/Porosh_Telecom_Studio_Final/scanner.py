"""Windows WIA scan bridge. Availability depends on installed WIA-capable driver."""
import os
from pathlib import Path
JPEG_GUID='{B96B3CAE-0728-11D3-9D7B-0000F81EF32E}'

def devices():
    if os.name!='nt':return []
    try:
        import pythoncom
        from win32com.client import Dispatch
        pythoncom.CoInitialize()
        try:
            manager=Dispatch('WIA.DeviceManager')
            return [{'index':i,'name':str(info.Properties('Name').Value)} for i,info in enumerate(manager.DeviceInfos,1) if int(info.Type)==1]
        finally:pythoncom.CoUninitialize()
    except Exception:return []

def scan_to_file(path,dpi=200,device_index=1):
    if os.name!='nt':raise RuntimeError('Windows PC-তে WIA স্ক্যানার লাগবে')
    dpi=int(dpi)
    if dpi not in (100,150,200,300):raise ValueError('স্ক্যান DPI 100/150/200/300 হতে হবে')
    try:
        import pythoncom
        from win32com.client import Dispatch
        pythoncom.CoInitialize()
        try:return _scan_connected(path,dpi,device_index,Dispatch)
        finally:pythoncom.CoUninitialize()
    except (ValueError,RuntimeError):raise
    except Exception as exc:
        raise RuntimeError('WIA স্ক্যান সম্পন্ন হয়নি। Epson Scan 2 থাকলেও WIA ড্রাইভার আলাদা লাগতে পারে: '+str(exc)[:130])

def _scan_connected(path,dpi,device_index,Dispatch):
    manager=Dispatch('WIA.DeviceManager')
    infos=manager.DeviceInfos
    idx=int(device_index)
    if idx<1 or idx>infos.Count:raise ValueError('স্ক্যানারটি পাওয়া যায়নি')
    device=infos.Item(idx).Connect()
    item=device.Items.Item(1)
    for key in ('6147','6148'):
        item.Properties.Item(key).Value=dpi
    image=item.Transfer(JPEG_GUID)
    raw=bytes(image.FileData.BinaryData)
    if not raw:raise RuntimeError('স্ক্যানার খালি ফাইল পাঠিয়েছে')
    Path(path).write_bytes(raw)
    return {'bytes':len(raw),'dpi_requested':dpi}
